/**
 * VOICE MODE: useSDKRealtimeSession Hook
 * =====================================
 * 
 * This hook implements the OpenAI multi-agent approach for voice mode:
 * 
 * 1. DIRECT AGENT CREATION:
 *    - Creates RealtimeAgent objects directly (no wrapper classes)
 *    - Uses createVoiceModeAgent() function for clean agent creation
 *    - All agents share global user interaction state
 * 
 * 2. SESSION MANAGEMENT:
 *    - Creates session with ALL agents upfront
 *    - Uses selectedAgentName to determine primary agent
 *    - Uses session.update() for agent switching (no recreation)
 * 
 * 3. AGENT HANDOFF:
 *    - Listens for agent_handoff events from SDK
 *    - Updates selectedAgentName state
 *    - Calls onAgentTransfer callback
 * 
 * ⚠️ CRITICAL REMINDER: DO NOT IMPLEMENT SESSION DISCONNECT/RECONNECT FOR AGENT SWITCHING!
 * =========================================================================================
 * 
 * ❌ WRONG APPROACH (DON'T DO THIS):
 * - Disconnecting and reconnecting sessions for agent switching
 * - Creating new RealtimeSession instances for each agent change
 * - Manual session recreation with different root agents
 * - Using disconnect() followed by connect() for agent changes
 * 
 * ✅ CORRECT APPROACH (CURRENT IMPLEMENTATION):
 * - Let OpenAI SDK handle agent switching automatically via agent_handoff events
 * - Maintain single session throughout the conversation
 * - Only update UI state when agent changes
 * - Use session.update() if needed, but avoid disconnection
 * 
 * The OpenAI multi-agent approach works within a single session where:
 * 1. All agents are available in the session
 * 2. SDK automatically switches agents based on function calls
 * 3. agent_handoff events notify us of switches
 * 4. We only need to update UI state, not recreate sessions
 * 
 * If you're tempted to add disconnect/reconnect logic, STOP and read this comment again!
 * 
 * 4. GLOBAL USER INTERACTION:
 *    - Single global state: globalUserInteracted
 *    - Marked via markGlobalUserInteraction()
 *    - All tools check this state before execution
 */

import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { RealtimeSession, OpenAIRealtimeWebRTC } from '@openai/agents/realtime';
import { createVoiceModeAgent, markGlobalUserInteraction, setGlobalAgentHandoffTrigger } from '@/app/lib/sdk-agent-wrapper';
// Note: transferAgents and transferBack are now core tools, no injection needed
import { CORE_SCHEMAS, UI_SCHEMAS, ALL_HANDLERS } from '@/app/agents/core/functions';
import { AgentConfig } from '@/app/types';
import { UniversalMessage } from '@/app/types';
import { getOrCreateDbSession } from '@/app/lib/sharedSessionManager';
import { getBotActionFunctionDefinitions } from '@/botActionFramework/FunctionCallMapper';

interface UseSDKRealtimeSessionProps {
  // Multi-agent configuration (OpenAI approach)
  allAgentConfigs: AgentConfig[];
  selectedAgentName: string;
  onMessage?: (message: UniversalMessage) => void;
  onError?: (error: Error) => void;
  sessionId: string;
  onAgentTransfer?: (agentName: string) => void;
  // Voice control options
  enabled?: boolean;
  acceptResponses?: boolean;
  muteAudio?: boolean;
  shouldAcceptResponseStart?: () => boolean;
  onUserVoiceItemCreated?: (initialText?: string) => void;
  // Response callbacks for UI updates
  onResponseStart?: () => void;
  onResponseStartFromDelta?: (agentName?: string) => void;
  onResponseDelta?: (delta: string) => void;
  onResponseDone?: (text: string, agentName?: string) => void;
  onTranscript?: (text: string) => void;
  onTranscriptDelta?: (delta: string) => void;
  // Preferred input transcription language (BCP-47 or provider code, e.g. 'th' or 'th-TH')
  transcriptionLanguage?: string;
  // Agent management for function calls
  dynamicAgentSets?: { [key: string]: any[] };
  activeAgentSetKeyState?: string;
  setActiveAgentSetKeyState?: (key: string) => void;
  setActiveAgentNameState?: (name: string) => void;
  messages?: UniversalMessage[];
}

interface UseSDKRealtimeSessionReturn {
  session: RealtimeSession | null;
  isConnected: boolean;
  isConnecting: boolean;
  error: string | null;
  sendMessage: (message: string) => Promise<void>;
  startVoice: () => Promise<void>;
  stopVoice: () => void;
  disconnect: () => void;
  interrupt: () => void;
  isVoiceActive: boolean;
  isPTTActive: boolean;
  setIsPTTActive: (active: boolean) => void;
  isPTTUserSpeaking: boolean;
  mute: (mute: boolean) => void;
  markUserInteraction: () => void;
}

/**
 * SDK hook for Realtime API with PTT support
 * - Push-to-talk voice input
 * - WebRTC audio handling
 * - UniversalMessage integration
 * - Database session management
 */
export function useSDKRealtimeSession({
  allAgentConfigs,
  selectedAgentName,
  onMessage,
  onError,
  sessionId,
  onAgentTransfer,
  enabled = true,
  acceptResponses = true,
  muteAudio = false,
  shouldAcceptResponseStart,
  onUserVoiceItemCreated,
  onResponseStart,
  onResponseStartFromDelta,
  onResponseDelta,
  onResponseDone,
  onTranscript,
  onTranscriptDelta,
  transcriptionLanguage,
  dynamicAgentSets = {},
  activeAgentSetKeyState,
  setActiveAgentSetKeyState,
  setActiveAgentNameState,
  messages = []
}: UseSDKRealtimeSessionProps): UseSDKRealtimeSessionReturn {

  const [session, setSession] = useState<RealtimeSession | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [isPTTActive, setIsPTTActive] = useState(false);
  const [isPTTUserSpeaking, setIsPTTUserSpeaking] = useState(false);

  // Multi-agent approach: Store agent wrappers for markUserInteraction access
  const sessionRef = useRef<RealtimeSession | null>(null);
  const dbSessionIdRef = useRef<string>('');
  const currentResponseRef = useRef<any>(null);
  // VOICE MODE: No agent wrappers needed - using direct agent creation
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const audioSenderRef = useRef<RTCRtpSender | null>(null);
  const pttStartAtRef = useRef<number>(0);
  const allowAgentRunsRef = useRef<boolean>(false);
  const hasAttemptedConnectionRef = useRef<boolean>(false);
  const aiPlaceholderCreatedRef = useRef<boolean>(false);
  const userTranscriptionCompleteRef = useRef<boolean>(false);
  
  // Response state tracking to prevent duplicate response creation
  const isResponseActiveRef = useRef<boolean>(false);
  const activeResponseIdRef = useRef<string | null>(null);
  const responseCreationLockRef = useRef<boolean>(false);
  const responseCreationQueueRef = useRef<Array<() => Promise<void>>>([]);
  const isProcessingQueueRef = useRef<boolean>(false);
  
  // Event-based waiting for response completion
  const responseCompletionPromiseRef = useRef<Promise<void> | null>(null);
  const responseCompletionResolveRef = useRef<(() => void) | null>(null);
  // Track function_call name per call_id for better logs when events omit name
  const functionCallNameByIdRef = useRef<Map<string, string>>(new Map());
  // Flag that prevents duplicate finalization between transcript.done and response.done fallback
  const assistantResponseHandledRef = useRef<boolean>(false);
  
  // Helper function to reset response state (useful for agent transfers)
  const resetResponseState = useCallback(() => {
    isResponseActiveRef.current = false;
    activeResponseIdRef.current = null;
    responseCreationLockRef.current = false;
    responseCreationQueueRef.current = [];
    isProcessingQueueRef.current = false;
    console.log('[SDK-Realtime] 🔄 Response state manually reset');
  }, []);

  // Create a promise that resolves when response.done is received
  const waitForResponseDone = useCallback(() => {
    if (!responseCompletionPromiseRef.current) {
      responseCompletionPromiseRef.current = new Promise<void>((resolve) => {
        responseCompletionResolveRef.current = resolve;
      });
    }
    return responseCompletionPromiseRef.current;
  }, []);

  // Reset the promise when response is done
  const resetResponseCompletionPromise = useCallback(() => {
    responseCompletionPromiseRef.current = null;
    responseCompletionResolveRef.current = null;
  }, []);

  // Queue-based response creation to prevent race conditions
  const processResponseQueue = useCallback(async () => {
    if (isProcessingQueueRef.current || responseCreationQueueRef.current.length === 0) {
      return;
    }
    
    isProcessingQueueRef.current = true;
    
    while (responseCreationQueueRef.current.length > 0) {
      const responseCreator = responseCreationQueueRef.current.shift();
      if (responseCreator) {
        try {
          await responseCreator();
        } catch (error) {
          console.error('[SDK-Realtime] ❌ Error in response queue processing:', error);
        }
      }
    }
    
    isProcessingQueueRef.current = false;
  }, []);

  // Helper function to safely create responses (prevents duplicate response creation)
  const safeCreateResponse = useCallback(async () => {
    const callId = `call_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    console.log('[SDK-Realtime] 🔍 safeCreateResponse called:', {
      callId,
      isResponseActive: isResponseActiveRef.current,
      activeResponseId: activeResponseIdRef.current,
      hasSession: !!sessionRef.current,
      isLocked: responseCreationLockRef.current,
      queueLength: responseCreationQueueRef.current.length,
      timestamp: new Date().toISOString()
    });
    
    // Add to queue instead of direct execution
    return new Promise<boolean>((resolve) => {
      responseCreationQueueRef.current.push(async () => {
        try {
          // Check if response creation is already in progress (lock)
          if (responseCreationLockRef.current) {
            console.log('[SDK-Realtime] ⚠️ Skipping response.create - creation already in progress (locked):', callId);
            resolve(false);
            return;
          }
          
          if (isResponseActiveRef.current) {
            console.log('[SDK-Realtime] ⚠️ Skipping response.create - response already active:', activeResponseIdRef.current, callId);
            resolve(false);
            return;
          }
          
          if (!sessionRef.current) {
            console.log('[SDK-Realtime] ⚠️ Skipping response.create - no active session:', callId);
            resolve(false);
            return;
          }
          
          // Set lock to prevent concurrent calls
          responseCreationLockRef.current = true;
          isResponseActiveRef.current = true;
          
          console.log('[SDK-Realtime] 🔒 Lock set, sending response.create event:', callId);
          sendEventSafe({ type: 'response.create' });
          console.log('[SDK-Realtime] ✅ Response creation initiated:', callId);
          resolve(true);
        } catch (error) {
          console.error('[SDK-Realtime] ❌ Failed to create response:', callId, error);
          isResponseActiveRef.current = false;
          responseCreationLockRef.current = false;
          resolve(false);
        }
      });
      
      // Process the queue
      processResponseQueue();
    });
  }, [processResponseQueue]);

  const previousAgentNameRef = useRef<string>('');
  const transferContextRef = useRef<{agentName: string, rationale: string, context: string} | null>(null);
  const handoffKickoffSentRef = useRef<boolean>(false);
  // Keep live refs in event handlers
  const selectedAgentNameRef = useRef<string>(selectedAgentName);
  // Tracks which agent is expected to produce the next assistant output
  const currentOutputAgentRef = useRef<string>('');
  // Tracks the currently applied TTS voice at the session level
  const appliedVoiceRef = useRef<string>('');
  // Queue a pending voice change when assistant audio is active
  const pendingVoiceRef = useRef<string | null>(null);
  // PTT response attempt tracking for fallback
  const pttCreateAttemptedRef = useRef<boolean>(false);
  const lastPTTCommitAtRef = useRef<number>(0);
  selectedAgentNameRef.current = selectedAgentName;
  const allAgentConfigsRef = useRef<AgentConfig[]>(allAgentConfigs);
  allAgentConfigsRef.current = allAgentConfigs;
  // Tracks the agent name most recently reported by the server as active
  const sessionReadyForAgentRef = useRef<string | null>(null);
  // Feature flag for auto-kickoff after handoff; default disabled to match App.tsx
  const enableAgentEndKickoffRef = useRef<boolean>(false);

  // Safe event sender with basic type validation and connection guard
  const sendEventSafe = useCallback((evt: any) => {
    try {
      if (!sessionRef.current || !(sessionRef.current as any)?.transport?.sendEvent) {
        console.warn('[SDK-Realtime] ⚠️ sendEvent skipped - no active transport');
        return false;
      }
      const allowed = new Set([
        'session.update',
        'transcription_session.update',
        'input_audio_buffer.append',
        'input_audio_buffer.commit',
        'input_audio_buffer.clear',
        'conversation.item.create',
        'response.create',
        'response.cancel',
        // Needed to acknowledge tool execution back to the server orchestrator
        'response.function_call_output'
      ]);
      const t = (evt && evt.type) || '';
      if (!allowed.has(t)) {
        console.warn('[SDK-Realtime] ⚠️ Invalid event type, skipping:', t, 'evt=', evt);
        return false;
      }
      (sessionRef.current as any).transport.sendEvent(evt);
      return true;
    } catch (e) {
      console.warn('[SDK-Realtime] ⚠️ sendEventSafe failed:', e);
      return false;
    }
  }, []);

  // Get current agent config
  const currentAgentConfig = useMemo(() => {
    if (!allAgentConfigs || allAgentConfigs.length === 0) {
      return null;
    }
    return allAgentConfigs.find(config => config.name === selectedAgentName) || allAgentConfigs[0];
  }, [allAgentConfigs, selectedAgentName]);

  // Store onMessage in ref to avoid recreating agents
  const onMessageRef = useRef(onMessage);
  onMessageRef.current = onMessage;

  // Store onAgentTransfer in ref to avoid recreating handoff trigger
  const onAgentTransferRef = useRef(onAgentTransfer);
  onAgentTransferRef.current = onAgentTransfer;

  // Store global handoff trigger in ref for access from function call handlers
  const globalAgentHandoffTriggerRef = useRef<((targetAgent: string, context: any) => void) | null>(null);

  // Set up global agent handoff trigger (only once)
  // ⚠️ CRITICAL: This function ONLY updates UI state - it does NOT disconnect/reconnect sessions!
  // The actual agent switching is handled by the OpenAI SDK automatically via agent_handoff events.
  useEffect(() => {
    const handoffTrigger = (targetAgent: string, context: any) => {
      console.log('[SDK-Realtime] 🎯 GLOBAL HANDOFF TRIGGER CALLED!', { targetAgent, context, isConnected, isConnecting });

      // The SDK handles agent handoffs automatically when connected
      // We just need to update the UI state
      console.log('[SDK-Realtime] 🎯 Agent handoff triggered:', targetAgent);

      // Update the active agent name state
      setActiveAgentNameState?.(targetAgent);

      // Call the agent transfer callback
      onAgentTransferRef.current?.(targetAgent);

      console.log('[SDK-Realtime] ✅ Agent handoff completed, SDK will handle the rest:', targetAgent);
    };

    // Store the handoff trigger in ref for access from function call handlers
    globalAgentHandoffTriggerRef.current = handoffTrigger;
    setGlobalAgentHandoffTrigger(handoffTrigger);

    return () => {
      setGlobalAgentHandoffTrigger(() => { });
    };
  }, []); // Remove dependencies to prevent re-creation

  // VOICE MODE: Create all SDK agents directly (no wrapper concept)
  const allSDKAgents = useMemo(() => {
    if (!allAgentConfigs || allAgentConfigs.length === 0) {
      return [];
    }

    console.log('[SDK-Voice] 🔄 Creating all voice mode agents from configs:', allAgentConfigs.map(c => c.name));

    // First, add downstream agents to all configs
    const agentsWithDownstream = allAgentConfigs.map(agentConfig => {
      const downstreamAgents = allAgentConfigs
        .filter(a => a.name !== agentConfig.name)
        .map(a => ({ name: a.name, publicDescription: a.publicDescription }));

      return {
        ...agentConfig,
        downstreamAgents: downstreamAgents
      };
    });

    // Inject all core functions like text mode does
    console.log('[SDK-Voice] 🔧 Injecting core functions for voice mode...');
    console.log('[SDK-Voice] 🔍 Before injection - welcomeAgent downstreamAgents:',
      agentsWithDownstream.find(a => a.name === 'welcomeAgent')?.downstreamAgents?.map(d => d.name) || []
    );

    // Note: transferAgents and transferBack are now core tools, no injection needed
    const agentsWithTransfers = agentsWithDownstream;

    // Then inject all core and UI schemas like text mode does
    const coreAndUiSchemas = [...CORE_SCHEMAS, ...UI_SCHEMAS];
    // Voice mode: avoid exposing generic transfer tools to the model to prevent confusion
    const SKIP_TOOL_NAMES = new Set(['transferAgents', 'transferBack', 'intentionChange']);
    // Restrict certain tools to specific agents only (from DB design)
    const ONLY_AGENT_FOR_TOOL: Record<string, string> = {
      placeKnowledgeSearch: 'placeGuide',
    };

    // Add core functions to all agents (avoiding duplicates)
    const agentsWithCoreFunctions = agentsWithTransfers.map(agentConfig => {
      const existingToolNames = new Set((agentConfig.tools || []).map((t: any) => t.name || t.function?.name));
      const newTools = coreAndUiSchemas.filter(schema => {
        const toolName = (schema as any).name || (schema as any).function?.name;
        // Skip generic transfer tools in voice mode
        if (SKIP_TOOL_NAMES.has(toolName)) return false;
        // Enforce per-agent restriction
        const onlyAgent = ONLY_AGENT_FOR_TOOL[toolName as string];
        if (onlyAgent && agentConfig.name !== onlyAgent) return false;
        return !existingToolNames.has(toolName);
      });
      
      // Also filter out any existing instances of the skipped tools and enforce per-agent restriction on DB-provided tools
      const filteredExisting = (agentConfig.tools || []).filter((t: any) => {
        const nm = t.name || t.function?.name;
        if (SKIP_TOOL_NAMES.has(nm)) return false;
        const onlyAgent = ONLY_AGENT_FOR_TOOL[nm as string];
        if (onlyAgent && agentConfig.name !== onlyAgent) return false;
        return true;
      });
      
      return {
        ...agentConfig,
        tools: [...filteredExisting, ...newTools]
      };
    });

    console.log('[SDK-Voice] 🔍 After injection - welcomeAgent tools count:',
      agentsWithCoreFunctions.find(a => a.name === 'welcomeAgent')?.tools?.length || 0
    );

    // Create SDK agents (no alias transfer tools; use proper handoffs instead)
    const sdkAgents = agentsWithCoreFunctions.map(agentConfig => {
      return createVoiceModeAgent(agentConfig, (message: string) => {
        const universalMessage: UniversalMessage = {
          id: `msg-${Date.now()}`,
          sessionId,
          timestamp: new Date().toISOString(),
          type: 'text',
          content: message,
          metadata: {
            source: 'ai',
            channel: 'realtime',
            language: 'en',
            agentName: agentConfig.name
          }
        };
        onMessageRef.current?.(universalMessage);
      });
    });

    // Wire up handoffs: each agent can handoff to all others in the same set
    try {
      const nameToAgent = new Map<string, any>();
      sdkAgents.forEach((a: any) => nameToAgent.set(a.name, a));
      sdkAgents.forEach((a: any) => {
        const others = sdkAgents.filter((b: any) => b.name !== a.name);
        (a as any).handoffs = others;
      });
      console.log('[SDK-Voice] 🔗 Handoffs wired between agents:', sdkAgents.map((a: any) => ({ name: a.name, handoffs: (a.handoffs || []).map((h: any) => h.name) })));
    } catch (e) {
      console.warn('[SDK-Voice] ⚠️ Failed wiring handoffs', e);
    }

    return sdkAgents;
  }, [allAgentConfigs, sessionId]);

  // Initialize database session
  useEffect(() => {
    if (dbSessionIdRef.current) return;

    const initializeDbSession = async () => {
      try {
        const dbSessionId = await getOrCreateDbSession(sessionId, 'voice');
        dbSessionIdRef.current = dbSessionId;
      } catch (err) {
        console.warn('[SDK] Failed to get session, using frontend session:', err);
        dbSessionIdRef.current = sessionId;
      }
    };

    initializeDbSession();
  }, [sessionId]);

  // Multi-agent approach: No need to create agent wrappers during runtime
  // All agents are created upfront in allSDKAgents useMemo

  // Mark user interaction to enable tool execution
  const markUserInteraction = useCallback(() => {
    console.log('[SDK-Realtime] 👤 Marking global user interaction');
    markGlobalUserInteraction();
  }, []);

  // Update session configuration for PTT mode
  const updateSession = useCallback(async (shouldTriggerResponse: boolean = false) => {
    if (!sessionRef.current || !isConnected) {
      console.log('[SDK-Realtime] ⏭️ Skipping updateSession - no session or not connected');
      return;
    }

    // PTT-only: disable server VAD always; we capture only during PTT via input_audio_buffer.*
    const turnDetection = null;

    console.log('[SDK-Realtime] 🔄 Updating session:', {
      selectedAgentName,
      isPTTActive,
      turnDetection,
      shouldTriggerResponse,
      timestamp: new Date().toISOString()
    });

    // Log the system prompt that will be used by the selected agent for clarity
    try {
      const cfg = (allAgentConfigsRef.current || []).find(c => c.name === selectedAgentName) || null;
      const instructions = (cfg?.instructions || cfg?.systemPrompt || '').toString();
      console.log('[SDK-Realtime] 🧾 updateSession: system prompt for agent:', {
        agentName: selectedAgentName,
        systemPromptLength: instructions.length,
        systemPromptPreview: instructions,
        fullSystemPrompt: instructions,
        source: cfg?.instructions ? 'instructions' : (cfg?.systemPrompt ? 'systemPrompt' : 'none')
      });
    } catch {}

    try {
      const sessionPayload: any = {
        type: 'session.update',
        session: {
          turn_detection: turnDetection,
          input_audio_transcription: {
            model: 'gpt-4o-mini-transcribe',
            language: transcriptionLanguage,
          }
        }
      };

      // Do not update voice here to avoid cannot_update_voice; rely on agent voice config
      sendEventSafe(sessionPayload);
      console.log('[SDK-Realtime] ✅ Session update sent successfully for agent:', selectedAgentName, {
        includedVoice: false
      });

      // When PTT is active, clear any existing audio buffer
      if (isPTTActive) {
        sendEventSafe({ type: 'input_audio_buffer.clear' });
      }

      // Send initial message to trigger agent response (OpenAI approach)
      if (shouldTriggerResponse) {
        const messageId = `msg-${Date.now()}`;
        sendEventSafe({
          type: 'conversation.item.create',
          item: {
            id: messageId,
            type: 'message',
            role: 'user',
            content: [{ type: 'input_text', text: 'hi' }],
          },
        });
        await safeCreateResponse();
        console.log('[SDK-Realtime] ✅ Sent initial trigger message to new agent');
      }
    } catch (e) {
      console.error('[SDK-Realtime] ❌ Failed to update session:', {
        error: e,
        selectedAgentName,
        timestamp: new Date().toISOString()
      });
    }
  }, [isPTTActive, selectedAgentName, transcriptionLanguage]);

  // Helper to enable/disable local mic capture at the track level
  const setMicEnabled = useCallback((enabled: boolean) => {
    try {
      const sender = audioSenderRef.current;
      const track = sender?.track as MediaStreamTrack | undefined;
      if (track && typeof track.enabled !== 'undefined') {
        track.enabled = enabled;
        console.log('[SDK-Realtime] 🎚️ Mic track toggled:', enabled);
      } else {
        console.log('[SDK-Realtime] ⚠️ No local audio track found to toggle');
      }
    } catch (e) {
      console.warn('[SDK-Realtime] ⚠️ setMicEnabled failed:', e);
    }
  }, []);

  // Connect to Realtime API using SDK
  const connect = useCallback(async () => {
    if (!enabled) {
      return;
    }

    if (hasAttemptedConnectionRef.current) {
      return;
    }

    if (!allSDKAgents.length || !currentAgentConfig) {
      setError('No agent configurations available');
      return;
    }

    hasAttemptedConnectionRef.current = true;
    setIsConnecting(true);
    setError(null);

    try {
      // Create audio element for WebRTC
      const audioElement = document.createElement('audio');
      audioElement.autoplay = true;
      audioElement.muted = true; // default to muted until user enables
      audioElement.style.display = 'none';
      document.body.appendChild(audioElement);
      audioElementRef.current = audioElement;

      // Create transport
      const webRTCTransport = new OpenAIRealtimeWebRTC({
        audioElement,
        changePeerConnection: async (pc: RTCPeerConnection) => {
          // Keep a reference to the RTCPeerConnection to discover local audio sender
          peerConnectionRef.current = pc;
          // Attempt to capture audio sender soon after PC created
          setTimeout(() => {
            try {
              const senders = pc.getSenders?.() || [];
              const audioSender = senders.find((s: any) => s?.track?.kind === 'audio') || null;
              if (audioSender) {
                audioSenderRef.current = audioSender;
                // Disable mic track by default (PTT-only)
                setMicEnabled(false);
                console.log('[SDK-Realtime] 🎤 Local audio sender captured and disabled by default');
              } else {
                console.log('[SDK-Realtime] ⚠️ No audio sender found at PC init');
              }
            } catch (e) {
              console.warn('[SDK-Realtime] ⚠️ Discover audio sender failed:', e);
            }
          }, 300);
          return pc;
        },
      });

      // MULTI-AGENT APPROACH: Create session with ALL agents (not just one)
      // This follows the OpenAI App.tsx pattern where all agents are available
      console.log('[SDK-Realtime] 🔄 Creating multi-agent session with all agents:', allSDKAgents.map(a => a.name));
      console.log('[SDK-Realtime] 🎯 Selected agent for initial context:', selectedAgentName);

      // Log all agent configurations for debugging
      allSDKAgents.forEach(agent => {
        const instructions = typeof agent.instructions === 'string' ? agent.instructions : '';
        console.log('[SDK-Realtime] 📝 Agent configuration:', {
          agentName: agent.name,
          instructionsLength: instructions.length,
          instructionsPreview: instructions.substring(0, 200) + '...',
          toolsCount: agent.tools?.length || 0,
          toolNames: agent.tools?.map((t: any) => t.name) || []
        });
      });

      // OPENAI APP.TSX APPROACH: Reorder agents so selected agent becomes root
      const reorderedAgents = [...allSDKAgents];
      const selectedAgentIndex = reorderedAgents.findIndex(agent => agent.name === selectedAgentName);

      if (selectedAgentIndex > 0) {
        const [selectedAgent] = reorderedAgents.splice(selectedAgentIndex, 1);
        reorderedAgents.unshift(selectedAgent); // Move selected agent to front
      }

      const rootAgent = reorderedAgents[0];

      console.log('[SDK-Realtime] 🔄 Creating session with agents:', reorderedAgents.map(a => a.name));
      console.log('[SDK-Realtime] 🎯 Root agent (first):', rootAgent.name);
      console.log('[SDK-Realtime] 🎯 Selected agent:', selectedAgentName);
      console.log('[SDK-Realtime] 🎤 PTT Mode:', isPTTActive ? 'Enabled (microphone disabled)' : 'Disabled (microphone enabled)');
      try {
        const payloadPreview = reorderedAgents.map((a: any) => {
          const instr = typeof a.instructions === 'string' ? a.instructions : '';
          return {
            name: a.name,
            voice: a.voice,
            instructionsLength: instr.length,
            instructionsPreview: instr.substring(0, 300) + '...',
            fullSystemPrompt: instr
          };
        });
        console.log('[SDK-Realtime] 📦 Agents payload to RealtimeSession:', payloadPreview);
      } catch {}

      let newSession;
      try {
        // Create session with root agent - the SDK will handle multi-agent functionality
        // Only enable audio when user explicitly enables voice mode
        // Force PTT-only by disabling server VAD at session creation
        const turnDetection = null;

        newSession = new RealtimeSession(rootAgent, {
        transport: webRTCTransport,
        model: 'gpt-4o-realtime-preview-2025-06-03',
        config: {
          inputAudioFormat: 'pcm16',
          outputAudioFormat: 'pcm16',
          inputAudioTranscription: {
            model: 'gpt-4o-mini-transcribe',
              // Hint language at creation if available
              ...(transcriptionLanguage ? { language: transcriptionLanguage } : {}),
            },
            turnDetection: turnDetection || undefined
          }
        });
        
        // Keep a local copy for debugging/inspection only, and register agents via helper if supported
        (newSession as any).allAgents = reorderedAgents;
        try {
          if (typeof (newSession as any).setAgents === 'function') {
            (newSession as any).setAgents(reorderedAgents);
            console.log('[SDK-Realtime] ✅ Registered all agents with session via setAgents');
          }
        } catch {}
        
        console.log('[SDK-Realtime] ✅ Multi-agent RealtimeSession created successfully with root agent:', rootAgent.name);
        console.log('[SDK-Realtime] 📋 All agents available:', reorderedAgents.map(a => a.name));
      } catch (sessionError) {
        console.error('[SDK-Realtime] ❌ Failed to create multi-agent RealtimeSession:', {
          error: sessionError,
          message: (sessionError as any)?.message,
          stack: (sessionError as any)?.stack,
          rootAgentName: rootAgent.name,
          agentsCount: allSDKAgents.length,
          agentNames: allSDKAgents.map(a => a.name)
        });
        throw sessionError;
      }


      (newSession as any).on('error', (err: any) => {
        // Enhanced error logging with better serialization
        const errorDetails = {
          timestamp: new Date().toISOString(),
          event: 'error',
          message: err?.message || 'Unknown error',
          type: err?.type || 'unknown',
          code: err?.code || 'unknown',
          name: err?.name || 'Error',
          stack: err?.stack || 'No stack trace',
          // Safely serialize the error object
          rawError: err ? {
            ...err,
            // Convert any functions to strings to avoid serialization issues
            toString: err.toString ? err.toString() : '[Function]'
          } : null,
          // Try to extract nested error information
          nestedError: err?.error ? {
            message: err.error.message,
            type: err.error.type,
            code: err.error.code,
            name: err.error.name
          } : null
        };

        console.log('[SDK-Realtime] ❌ Detailed error analysis:', errorDetails);
        console.error('[SDK] Session error:', err);
        console.error('[SDK] Raw error object:', JSON.stringify(err, null, 2));

        // Gracefully ignore empty-commit errors (benign on very short taps)
        const nestedCode = (err as any)?.error?.error?.code;
        const topCode = (err as any)?.code;
        const code = nestedCode || topCode || '';
        if (code === 'input_audio_buffer_commit_empty') {
          console.warn('[SDK-Realtime] ⚠️ Ignoring empty audio buffer commit error (short PTT or no audio)');
          return;
        }

        // Set a more descriptive error message
        const errorMessage = err?.message || (err as any)?.error?.message || err?.type || 'Session error';
        setError(errorMessage);
        onError?.(new Error(errorMessage));
      });

      // Handle agent handoff events (OpenAI server-side switch)
      // After server switches, optionally send a kickoff using model-provided summary
      newSession.on('agent_handoff', async (event: any) => {
        console.log('[SDK-Realtime] 🎯 AGENT HANDOFF EVENT DETECTED!', {
          rawEvent: event,
          timestamp: new Date().toISOString()
        });

        handoffKickoffSentRef.current = false;

        const history = event.context?.history || [];
        const lastItem = history[history.length - 1];
        // Try to parse destination from function name like transfer_to_placeGuide
        let parsedName: string | undefined;
        if (lastItem?.name && typeof lastItem.name === 'string') {
          if (lastItem.name.startsWith('transfer_to_')) {
            parsedName = lastItem.name.replace('transfer_to_', '');
          } else if (lastItem.name.startsWith('transferAgents')) {
            parsedName = lastItem.name.replace('transferAgents', '');
          }
        }
        const agentName = parsedName || event.agent_name || '';

        // Try to retrieve a handoff summary provided by the model via tool args
        // Search last function_call item for a property like handoff_summary
        let handoffSummary = '';
        try {
          for (let i = history.length - 1; i >= 0; i--) {
            const it = history[i];
            if (it?.type === 'function_call' && typeof it?.arguments === 'string') {
              try {
                const parsed = JSON.parse(it.arguments);
                if (typeof parsed?.handoff_summary === 'string' && parsed.handoff_summary.trim().length > 0) {
                  handoffSummary = parsed.handoff_summary.trim();
                  break;
                }
              } catch {}
            }
          }
        } catch {}

        // Match App.tsx: update UI immediately on handoff so the next agent_start resolves
        if (agentName) {
          try {
            setActiveAgentNameState?.(agentName);
            onAgentTransfer?.(agentName);
            selectedAgentNameRef.current = agentName;
            console.log('[SDK-Realtime] ✅ UI agent switched on handoff to:', agentName);
          } catch (e) {
            console.warn('[SDK-Realtime] ⚠️ Failed to sync UI on handoff', e);
          }
        }

        // Wait for any in-flight response to finish to avoid active-response errors
        try {
          await waitForResponseDone();
        } catch {}

        // Store summary (if any) for optional use later; do not auto-kickoff
        try {
          const kickoff = handoffSummary && handoffSummary.length > 0 ? handoffSummary : '';
          transferContextRef.current = { agentName: agentName || '', rationale: '', context: kickoff };
          handoffKickoffSentRef.current = false;
          console.log('[SDK-Realtime] 📝 Stored kickoff summary for agent (deferred until response.done):', agentName);
        } catch {}
      });

      (newSession as any).on('connect', () => {
        // Log connection success
        console.log('[SDK-Realtime] 🔌 connect:', {
          timestamp: new Date().toISOString(),
          event: 'connect',
          isConnected: true,
          isConnecting: false
        });

        setIsConnected(true);
        setIsConnecting(false);
        // Register all agents with the server now that the transport is connected
        try {
          if (typeof (newSession as any).setAgents === 'function') {
            (newSession as any).setAgents(reorderedAgents);
            console.log('[SDK-Realtime] ✅ Registered all agents with session on connect via setAgents');
          } else {
            console.warn('[SDK-Realtime] ⚠️ session.setAgents not available on connect');
          }
        } catch (e) {
          console.warn('[SDK-Realtime] ⚠️ Failed to register agents on connect', e);
        }
        // Force transport mute until user initiates PTT or unmutes
        try { (newSession as any).mute?.(true); } catch {}
        // Ensure local mic track is disabled on connect
        setMicEnabled(false);
        updateSession();
      });

      // (Note) Only one agent_handoff handler is registered above.

      (newSession as any).on('disconnect', () => {
        // Log disconnection
        console.log('[SDK-Realtime] 🔌 disconnect:', {
          timestamp: new Date().toISOString(),
          event: 'disconnect',
          isConnected: false,
          isConnecting: false
        });

        setIsConnected(false);
        setIsConnecting(false);
      });


      // Note: Text response events (response.text.delta, response.text.done) are not used in voice mode
      // Voice mode uses response.audio_transcript.* events instead

      // Listen for transport events
      (newSession as any).on('transport_event', async (event: any) => {
        // Log all transport events for debugging
        if (event.type == "response.done") {
          console.log('[SDK-Realtime] 🚌 transport_event:', {
            timestamp: new Date().toISOString(),
            eventType: event.type,
            rawEvent: event,
            itemId: event.item_id,
            hasTranscript: !!event.transcript,
            hasDelta: !!event.delta,
            transcript: event.transcript,
            delta: event.delta
          });
        }

        switch (event.type) {
          case 'conversation.item.input_audio_transcription.completed': {
            const itemId = event.item_id;
            const finalTranscript = (event.transcript || '').trim();

            if (itemId && onTranscript && finalTranscript) {
              onTranscript(finalTranscript);
              userTranscriptionCompleteRef.current = true;
            }
            break;
          }
          case 'conversation.item.input_audio_transcription.delta': {
            if (event.delta && onTranscriptDelta) {
              try {
                onTranscriptDelta(event.delta);
              } catch (e) {
                console.error('[SDK] onTranscriptDelta error:', e);
              }
            }
            break;
          }
          case 'conversation.item.input_audio_transcription.failed': {
            console.warn('[SDK] Transcription failed:', event);
            break;
          }
          case 'response.audio_transcript.delta': {
            const itemId = event.item_id;
            const deltaText = event.delta || "";

            if (itemId && deltaText) {
              if (onResponseStartFromDelta && !aiPlaceholderCreatedRef.current) {
                try {
                  if (!currentResponseRef.current) {
                    currentResponseRef.current = {
                      id: `response-${Date.now()}`,
                      type: 'audio_transcript',
                      created_at: new Date().toISOString(),
                      content: [],
                      placeholderCreated: false
                    };
                  }
                  // Unmute playback at first assistant delta
                  try {
                    if (audioElementRef.current) {
                      audioElementRef.current.muted = false;
                      audioElementRef.current.play().catch(() => {});
                    }
                  } catch {}
                  onResponseStartFromDelta(currentOutputAgentRef.current);
                  aiPlaceholderCreatedRef.current = true;
                  if (currentResponseRef.current) {
                    currentResponseRef.current.placeholderCreated = true;
                  }
                } catch (e) {
                  console.error('[SDK] onResponseStartFromDelta error:', e);
                }
              }

              if (onResponseDelta) {
                try {
                  onResponseDelta(deltaText);
                } catch (e) {
                  console.error('[SDK] response.audio_transcript.delta error:', e);
                }
              }
            }
            break;
          }
          case 'response.audio_transcript.done': {
            const itemId = event.item_id;
            const finalTranscript = (event.transcript || '').trim();

            if (itemId && finalTranscript && onResponseDone) {
              try {
                console.log('[SDK-Realtime] 🗣️ Assistant transcript done from agent:', currentOutputAgentRef.current);
                assistantResponseHandledRef.current = true;
                onResponseDone(finalTranscript, currentOutputAgentRef.current);
              } catch (e) {
                console.error('[SDK] response.audio_transcript.done error:', e);
              }
            }
            break;
          }
          case 'response.audio.delta': {
            // Audio delta handled by WebRTC transport
            break;
          }
          case 'response.audio.done': {
            // Audio completion handled by WebRTC transport
            break;
          }
          case 'response.function_call_arguments.done': {
            // Log function call arguments completion (resolve name via prior output_item if missing)
            const resolvedName = (event.name || (event.call_id ? functionCallNameByIdRef.current.get(event.call_id) : undefined) || undefined);
            console.log('[SDK-Realtime] 🔧 function_call_arguments.done:', {
              timestamp: new Date().toISOString(),
              eventType: 'response.function_call_arguments.done',
              rawEvent: event,
              itemId: event.item_id,
              functionName: resolvedName,
              arguments: event.arguments,
              callId: event.call_id,
              status: event.status
            });
            break;
          }
          case 'response.output_item.done': {
            // Log output item completion (includes function calls)
            console.log('[SDK-Realtime] 📤 output_item.done:', {
              timestamp: new Date().toISOString(),
              eventType: 'response.output_item.done',
              rawEvent: event,
              itemId: event.item_id,
              itemType: event.item?.type,
              functionName: event.item?.name,
              arguments: event.item?.arguments,
              callId: event.item?.call_id,
              status: event.item?.status,
              responseId: event.response_id
            });
            // Track function name by call_id for better correlation
            try {
              if (event.item?.type === 'function_call' && event.item?.call_id && event.item?.name) {
                functionCallNameByIdRef.current.set(event.item.call_id, event.item.name);
              }
            } catch {}
            if (event.item?.type === 'message' || event.item?.type === 'assistant_response' || event.item?.type === 'audio_transcript') {
              console.log('[SDK-Realtime] 🧩 Output item attributed to agent:', currentOutputAgentRef.current);
            }
            break;
          }
          case 'response.done': {
            // Handle response completion and detect function calls
            console.log('[SDK-Realtime] 🏁 response.done transport event:', {
              timestamp: new Date().toISOString(),
              eventType: 'response.done',
              rawEvent: event,
              responseId: event.response?.id,
              status: event.response?.status,
              output: event.response?.output,
              hasOutput: !!event.response?.output?.length,
              voice: event.response?.voice || 'unknown',
              appliedVoice: appliedVoiceRef.current || 'unknown'
            });

            // Reset response state when response is done
            isResponseActiveRef.current = false;
            activeResponseIdRef.current = null;
            responseCreationLockRef.current = false;
            console.log('[SDK-Realtime] 🔄 Response state reset - ready for new responses');
            
            // Resolve the waiting promise if it exists
            if (responseCompletionResolveRef.current) {
              responseCompletionResolveRef.current();
              resetResponseCompletionPromise();
              console.log('[SDK-Realtime] ✅ Response completion promise resolved');
            }
            
            // Process any queued responses
            processResponseQueue();

            // Remove deferred voice update logic to avoid cannot_update_voice

            // Fallback: if no audio_transcript events were received, try to extract transcript text
            try {
              const outputs = Array.isArray(event.response?.output) ? event.response.output : [];
              let transcriptText = '';
              for (const item of outputs) {
                if (item?.type === 'message' && Array.isArray(item.content)) {
                  for (const c of item.content) {
                    if (typeof c?.transcript === 'string' && c.transcript.trim().length > 0) {
                      transcriptText = c.transcript.trim();
                      break;
                    }
                    if (typeof c?.text === 'string' && c.text.trim().length > 0) {
                      transcriptText = c.text.trim();
            break;
          }
        }
                }
                if (transcriptText) break;
              }
              if (transcriptText) {
                console.log('[SDK-Realtime] 🧩 Using response.done transcript fallback from agent:', currentOutputAgentRef.current);
                if (onResponseStartFromDelta) {
                  try { onResponseStartFromDelta(currentOutputAgentRef.current); } catch (e) { console.warn('[SDK] onResponseStartFromDelta fallback error:', e); }
                }
                if (onResponseDone) {
                  try { onResponseDone(transcriptText, currentOutputAgentRef.current); } catch (e) { console.warn('[SDK] onResponseDone fallback error:', e); }
                }
                }
              } catch (e) {
              console.warn('[SDK] Fallback transcript extraction failed:', e);
            }

            // No manual function-call execution here; rely on SDK tool execution (match App.tsx)
            break;
          }
          case 'session.updated': {
            // Minimal log; initial message is handled elsewhere (response.done flow)
            console.log('[SDK-Realtime] 🔄 session.updated transport event');
            break;
          }
        }
      });

      // Note: No manual tool execution block; tools are executed by the SDK

      // Response lifecycle management
      (newSession as any).on('response.created', (data: any) => {
        // Track active response
        isResponseActiveRef.current = true;
        activeResponseIdRef.current = data.id;
        assistantResponseHandledRef.current = false;
        // Ensure playback is unmuted for assistant audio regardless of input type
        try {
          if (audioElementRef.current) {
            audioElementRef.current.muted = false;
            audioElementRef.current.play().catch(() => {});
          }
        } catch {}
        
        // Log raw response creation data
        console.log('[SDK-Realtime] 🆕 response.created:', {
          timestamp: new Date().toISOString(),
          event: 'response.created',
          rawData: data,
          responseId: data.id,
          responseType: data.type,
          createdAt: data.created_at,
          allowAgentRuns: allowAgentRunsRef.current,
          acceptResponses
        });

        currentResponseRef.current = {
          id: data.id,
          type: data.type,
          created_at: data.created_at,
          content: []
        };
        aiPlaceholderCreatedRef.current = false;

        if (!allowAgentRunsRef.current) {
          try {
            sendEventSafe({ type: 'response.cancel' });
          } catch (e) {
            console.warn('[SDK] Auto-cancel failed', e);
          }
          return;
        }

        if (acceptResponses && (!shouldAcceptResponseStart || shouldAcceptResponseStart()) && onResponseStart) {
          try {
            onResponseStart();
          } catch (e) {
            console.error('[SDK] onResponseStart error:', e);
          }
        }
      });

      // Note: response.done is handled through transport_event system, not direct event

      // Agent events with PTT-aware blocking
      (newSession as any).on('agent_start', (data: any) => {
        // Log raw agent start data
        const serverAgentName = (data as any)?.agent_name || (data as any)?.agent?.name || null;
        // Resolve the selected agent config using live refs to avoid stale closures
        const effectiveName = serverAgentName || selectedAgentNameRef.current;
        const selectedAgentConfig = (allAgentConfigsRef.current || []).find((c) => c.name === effectiveName) || (allAgentConfigsRef.current || [])[0] || null;
        console.log('[SDK-Realtime] 🤖 agent_start:', {
          timestamp: new Date().toISOString(),
          event: 'agent_start',
          rawData: data,
          allowAgentRuns: allowAgentRunsRef.current,
          serverAgentName,
          uiSelectedAgentName: selectedAgentNameRef.current
        });

        // Log the agent's current configuration when it starts
        if (selectedAgentConfig) {
          const instructions = selectedAgentConfig.instructions || selectedAgentConfig.systemPrompt || '';
          console.log('[SDK-Realtime] 📝 Agent starting with configuration:', {
            agentName: effectiveName,
            systemPromptLength: instructions.length,
            systemPromptPreview: instructions.substring(0, 300) + '...',
            fullSystemPrompt: instructions,
            source: selectedAgentConfig.instructions ? 'instructions' : (selectedAgentConfig.systemPrompt ? 'systemPrompt' : 'none'),
            toolsCount: selectedAgentConfig.tools?.length || 0,
            toolNames: selectedAgentConfig.tools?.map((t: any) => t.function?.name || t.name) || [],
            downstreamAgents: selectedAgentConfig.downstreamAgents?.map((a: any) => a.name) || []
          });

          // Additional explicit logs to ensure full visibility in consoles that truncate object fields
          try {
            console.log(`[SDK-Realtime] 🧾 Agent full prompt (${effectiveName}):`);
            // console.log(instructions);
          } catch {}

          try {
            const toolSummaries = (selectedAgentConfig.tools || []).map((t: any) => {
              const name = t.function?.name || t.name;
              const description = t.function?.description || t.description || '';
              const parameters = t.function?.parameters || t.parameters || undefined;
              const paramKeys = parameters?.properties ? Object.keys(parameters.properties) : [];
              return { name, description, paramKeys };
            });
            console.log(`[SDK-Realtime] 🧰 Agent tools (${effectiveName}) [${toolSummaries.length}]:`, toolSummaries);
          } catch {}
        }

        // Keep UI in sync with server-reported agent and mark session-ready agent
        try {
          sessionReadyForAgentRef.current = effectiveName || null;
          currentOutputAgentRef.current = effectiveName || '';
          console.log('[SDK-Realtime] ✅ Session ready for agent:', sessionReadyForAgentRef.current);
          if (serverAgentName && serverAgentName !== currentAgentConfig?.name) {
            setActiveAgentNameState?.(serverAgentName);
            onAgentTransfer?.(serverAgentName);
            console.log('[SDK-Realtime] 🔄 Synced UI selected agent with server agent_start:', serverAgentName);
          }
        } catch {}

        if (!allowAgentRunsRef.current) {
          try { sendEventSafe({ type: 'input_audio_buffer.clear' }); } catch { }
          return;
        }
      });

      (newSession as any).on('agent_end', async (data: any) => {
        // Log raw agent end data
        console.log('[SDK-Realtime] 🏁 agent_end:', {
          timestamp: new Date().toISOString(),
          event: 'agent_end',
          rawData: data,
          allowAgentRuns: allowAgentRunsRef.current
        });

        if (!allowAgentRunsRef.current) {
          try { sendEventSafe({ type: 'input_audio_buffer.clear' }); } catch { }
          return;
        }

        // Match App.tsx: do not send any kickoff automatically here
        try { transferContextRef.current = null; handoffKickoffSentRef.current = true; } catch {}
      });

      (newSession as any).on('response.create', (data: any) => {
        // Log raw response create data
        console.log('[SDK-Realtime] 🎬 response.create:', {
          timestamp: new Date().toISOString(),
          event: 'response.create',
          rawData: data,
          allowAgentRuns: allowAgentRunsRef.current
        });

        if (!allowAgentRunsRef.current) {
          try { sendEventSafe({ type: 'input_audio_buffer.clear' }); } catch { }
          return;
        }
      });

      // User voice item creation
      (newSession as any).on('conversation.item.created', (data: any) => {
        // Log raw conversation item creation data
        console.log('[SDK-Realtime] 💬 conversation.item.created:', {
          timestamp: new Date().toISOString(),
          event: 'conversation.item.created',
          rawData: data,
          itemRole: data?.item?.role,
          itemType: data?.item?.type,
          itemContent: data?.item?.content,
          hasText: !!(data?.item?.content?.[0]?.text || data?.item?.content?.[0]?.transcript),
          text: data?.item?.content?.[0]?.text || data?.item?.content?.[0]?.transcript || ''
        });

        try {
          const role = data?.item?.role;
          const type = data?.item?.type;
          const text = data?.item?.content?.[0]?.text || data?.item?.content?.[0]?.transcript || '';

          console.log('[SDK-Realtime] 🔍 conversation.item.created analysis:', {
            role,
            type,
            text: text.trim(),
            hasText: !!text.trim(),
            isUser: role === 'user'
          });

          // Mark user interaction when SDK receives user message
          if (role === 'user' && text.trim()) {
            console.log('[SDK-Realtime] 👤 User message detected, calling markUserInteraction()');
            markUserInteraction();
            console.log('[SDK-Realtime] 👤 User interaction marked via SDK conversation.item.created - tools now enabled');
            // If a user message arrives after handoff, cancel any pending kickoff to avoid conflicts
            try {
              if (transferContextRef.current && !handoffKickoffSentRef.current) {
                console.log('[SDK-Realtime] ⏭️ Clearing pending kickoff due to new user message');
                transferContextRef.current = null;
                handoffKickoffSentRef.current = true;
              }
            } catch {}
          } else {
            console.log('[SDK-Realtime] ⏭️ Skipping markUserInteraction - not a user message or no text');
          }

          if (role === 'user' || type === 'input_audio') {
            onUserVoiceItemCreated?.(typeof text === 'string' ? text : undefined);
            // Clear pending kickoff on any user-initiated input (text or audio)
            try {
              if (transferContextRef.current && !handoffKickoffSentRef.current) {
                console.log('[SDK-Realtime] ⏭️ Clearing pending kickoff due to user audio/input');
                transferContextRef.current = null;
                handoffKickoffSentRef.current = true;
              }
            } catch {}
          }
        } catch (error) {
          console.error('[SDK-Realtime] ❌ Error in conversation.item.created handler:', error);
        }
      });

      // Get ephemeral key from /api/session endpoint
      let ephemeralKey: string;
      try {
        // Add cache-busting parameter to force new server-side session
        const cacheBuster = `t=${Date.now()}&r=${Math.random().toString(36).substr(2, 9)}`;
        const tokenResponse = await fetch(`/api/session?${cacheBuster}`, {
          headers: {
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0'
          }
        });
        const data = await tokenResponse.json();
        console.log('[SDK-Realtime] API response:', data);

        if (!data.client_secret?.value) {
          console.error('[SDK-Realtime] Invalid API response:', data);
          throw new Error(`No ephemeral key provided by the server. Response: ${JSON.stringify(data)}`);
        }

        ephemeralKey = data.client_secret.value;
      } catch (err) {
        console.error('[SDK] Failed to get ephemeral key:', err);
        setError('Failed to get ephemeral key from server');
        setIsConnecting(false);
        setIsConnected(false);
        onError?.(err instanceof Error ? err : new Error('Failed to get ephemeral key'));
        return;
      }

      try {
        const connectionPromise = newSession.connect({ apiKey: ephemeralKey });
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Connection timeout')), 10000)
        );

        await Promise.race([connectionPromise, timeoutPromise]);
      } catch (err: any) {
        console.error('[SDK] Connection failed:', err?.message || err);
        setError(`Connection failed: ${err?.message || 'Unknown error'}`);
        setIsConnecting(false);
        setIsConnected(false);
        onError?.(err instanceof Error ? err : new Error('Connection failed'));
        return;
      }

      sessionRef.current = newSession;
      setSession(newSession);
      setIsConnected(true);
      setIsConnecting(false);
      updateSession();

      // No pending message system needed with multi-agent approach


    } catch (err) {
      console.error('[SDK] Connection failed:', err);
      setIsConnecting(false);
      setError(err instanceof Error ? err.message : 'Connection failed');
      onError?.(err instanceof Error ? err : new Error('Connection failed'));
    }
  }, [currentAgentConfig, onMessage, onError, onAgentTransfer, sessionId, enabled, acceptResponses, muteAudio, shouldAcceptResponseStart, onUserVoiceItemCreated, onResponseStart, onResponseDelta, onResponseDone, onTranscript, onTranscriptDelta]);

  // React to muteAudio changes
  useEffect(() => {
    if (audioElementRef.current) {
      audioElementRef.current.muted = !!muteAudio;
    }
  }, [muteAudio]);

  // Send message through SDK session
  const sendMessage = useCallback(async (message: string) => {
    if (!sessionRef.current || !isConnected) {
      setError('Session not connected');
      return;
    }

    try {
      // Enable agent runs when user sends a message
      allowAgentRunsRef.current = true;

      // For text input, mark user transcription as complete immediately
      userTranscriptionCompleteRef.current = true;

      // Add user message to chat
      const userMessage: UniversalMessage = {
        id: `msg-${Date.now()}`,
        sessionId,
        timestamp: new Date().toISOString(),
        type: 'text',
        content: message,
        metadata: {
          source: 'user',
          channel: 'realtime',
          language: 'en'
        }
      };

      onMessage?.(userMessage);

      // Send through SDK
      await (sessionRef.current as any).sendMessage(message);

      // Log to database
      try {
        await fetch('/api/log/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            session_id: dbSessionIdRef.current,
            role: 'user',
            type: 'text',
            content: message,
            channel: 'realtime',
            meta: { is_internal: false }
          })
        });
      } catch (err) {
        console.warn('[SDK] Failed to log user message:', err);
      }

    } catch (err) {
      console.error('[SDK] Failed to send message:', err);
      setError(err instanceof Error ? err.message : 'Failed to send message');
      onError?.(err instanceof Error ? err : new Error('Failed to send message'));
    }
  }, [isConnected, onMessage, onError, sessionId]);

  // PTT button down handler
  const startVoice = useCallback(async () => {
    if (!sessionRef.current || !isConnected) {
      setError('Session not connected');
      return;
    }

    // Enable agent runs when user starts voice input
    allowAgentRunsRef.current = true;

    // Reset flags for new PTT session
    userTranscriptionCompleteRef.current = false;
    aiPlaceholderCreatedRef.current = false;
    pttCreateAttemptedRef.current = false;

    try {
      (sessionRef.current as any).interrupt?.();
    } catch (err) {
      console.error('[SDK] Failed to interrupt session:', err);
    }

    try {
      (sessionRef.current as any).transport?.sendEvent?.({ type: 'input_audio_buffer.clear' });
    } catch (err) {
      console.error('[SDK] Failed to clear audio buffer:', err);
    }

    // Mark PTT start time
    pttStartAtRef.current = Date.now();

    // Keep transport mute state unchanged; manage mic track + DOM audio to avoid feedback
    try { if (audioElementRef.current) { audioElementRef.current.muted = true; } } catch {}
    // Enable mic track for PTT window
    setMicEnabled(true);
    setIsPTTUserSpeaking(true);
    setIsVoiceActive(true);
  }, [isConnected, onError]);

  // PTT button up handler
  const stopVoice = useCallback(() => {
    if (!sessionRef.current || !isPTTUserSpeaking) {
      return;
    }

    // Ensure minimum capture time to avoid empty buffer commits
    const MIN_AUDIO_MS = 150;
    const elapsed = Date.now() - (pttStartAtRef.current || 0);
    const waitMs = Math.max(0, MIN_AUDIO_MS - Math.max(0, elapsed));

    setTimeout(async () => {
      // If we still have no sender/track, skip commit to avoid server error
      const track: MediaStreamTrack | undefined = (audioSenderRef.current?.track as any);
      if (!track) {
        console.warn('[SDK] Skipping input_audio_buffer.commit: no local audio track available');
      } else if (!track.enabled) {
        console.warn('[SDK] Skipping input_audio_buffer.commit: track disabled, likely no audio captured');
      } else {
        try {
          sendEventSafe({ type: 'input_audio_buffer.commit' });
          lastPTTCommitAtRef.current = Date.now();
      } catch (err) {
        console.error('[SDK] Failed to commit audio buffer:', err);
        }
      }

      // Only attempt to create a response if we issued a commit
      if (track && track.enabled) {
        try {
          const created = await safeCreateResponse();
          pttCreateAttemptedRef.current = true;
          if (!created) {
            // Retry once after a short delay if not created (e.g., lock/active settling)
            setTimeout(async () => {
              try {
                if (!isResponseActiveRef.current) {
                  await safeCreateResponse();
                }
              } catch (e) {
                console.warn('[SDK] Retry response.create failed:', e);
              }
            }, 250);
          }
      } catch (err) {
        console.error('[SDK] Failed to create response:', err);
        }
      }

      setIsPTTUserSpeaking(false);
      // Re-enable playback for assistant reply (audio element only)
      try { if (audioElementRef.current) { audioElementRef.current.muted = false; audioElementRef.current.play().catch(() => {}); } } catch {}
      // Disable mic track after PTT
      setMicEnabled(false);
    }, waitMs);

    setIsPTTUserSpeaking(false);
    setIsVoiceActive(false);
  }, [isPTTUserSpeaking, onError]);

  // Disconnect session
  const disconnect = useCallback(() => {
    if (!sessionRef.current) return;

    try {
      const s: any = sessionRef.current as any;

      if (typeof s.disconnect === 'function') {
        s.disconnect();
      } else if (typeof s.close === 'function') {
        s.close();
      } else if (typeof s.transport?.close === 'function') {
        s.transport.close();
      }
      sessionRef.current = null;
      setSession(null);
      setIsConnected(false);
      setIsVoiceActive(false);
    } catch (err) {
      console.error('[SDK] Failed to disconnect:', err);
      setError(err instanceof Error ? err.message : 'Failed to disconnect');
    }
  }, []);

  // Update session when PTT state changes
  useEffect(() => {
    if (isConnected) {
      updateSession();
    }
  }, [isPTTActive, isConnected, updateSession]);

  // Track agent changes for UI updates only (SDK handles actual agent switching)
  // ⚠️ CRITICAL REMINDER: DO NOT IMPLEMENT SESSION DISCONNECT/RECONNECT FOR AGENT SWITCHING!
  // 
  // ❌ WRONG APPROACH (DON'T DO THIS):
  // - Disconnecting and reconnecting sessions for agent switching
  // - Creating new RealtimeSession instances for each agent change
  // - Manual session recreation with different root agents
  //
  // ✅ CORRECT APPROACH (CURRENT IMPLEMENTATION):
  // - Let OpenAI SDK handle agent switching automatically via agent_handoff events
  // - Maintain single session throughout the conversation
  // - Only update UI state when agent changes
  // - Use session.update() if needed, but avoid disconnection
  //
  // The OpenAI multi-agent approach works within a single session where:
  // 1. All agents are available in the session
  // 2. SDK automatically switches agents based on function calls
  // 3. agent_handoff events notify us of switches
  // 4. We only need to update UI state, not recreate sessions
  useEffect(() => {
    if (selectedAgentName && previousAgentNameRef.current && previousAgentNameRef.current !== selectedAgentName) {
      console.log('[SDK-Realtime] 🎯 Agent change detected (UI only):', {
        from: previousAgentNameRef.current,
        to: selectedAgentName,
        isConnected,
        isConnecting,
        timestamp: new Date().toISOString()
      });

      // The SDK handles agent switching automatically via agent_handoff events
      // We only need to update the UI state here
      console.log('[SDK-Realtime] ✅ Agent change handled by SDK automatically');
    }
    previousAgentNameRef.current = selectedAgentName || '';
  }, [selectedAgentName, isConnected, isConnecting]);

  // Auto-connect when dependencies are ready
  useEffect(() => {
    if (enabled &&
      !isConnected &&
      !isConnecting &&
      currentAgentConfig?.tools &&
      currentAgentConfig.tools.length > 0) {
      console.log('[SDK-Realtime] 🔄 Auto-connecting with agent:', currentAgentConfig.name);
      connect();
    }
  }, [enabled, isConnected, isConnecting, currentAgentConfig?.tools?.length, connect]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      disconnect();
    };
  }, [disconnect]);

  // Mute function for client-side microphone control
  const mute = useCallback((mute: boolean) => {
      try {
      if (sessionRef.current && (sessionRef.current as any).mute) {
        (sessionRef.current as any).mute(mute);
      }
      if (audioElementRef.current) {
        audioElementRef.current.muted = !!mute;
        if (!mute) {
          audioElementRef.current.play().catch(() => {});
        }
      }
    } catch (e) {
      console.warn('[SDK] Failed to toggle mute:', e);
    }
  }, []);

  // Interrupt function
  const interrupt = useCallback(() => {
    if (sessionRef.current) {
      try {
        (sessionRef.current as any).interrupt?.();
      } catch (e) {
        console.warn('[SDK] Failed to interrupt:', e);
      }
    }
  }, []);

  return {
    session,
    isConnected,
    isConnecting,
    error,
    sendMessage,
    startVoice,
    stopVoice,
    disconnect,
    interrupt,
    isVoiceActive,
    isPTTActive,
    setIsPTTActive,
    isPTTUserSpeaking,
    mute,
    markUserInteraction
  };
}