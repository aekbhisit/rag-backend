import { useState, useEffect, useRef, useCallback } from 'react';
import { RealtimeSession, OpenAIRealtimeWebRTC, RealtimeAgent } from '@openai/agents/realtime';
import { DatabaseAgentWrapper } from '@/app/lib/sdk-agent-wrapper';
import { AgentConfig } from '@/app/types';
import { UniversalMessage } from '@/app/types';
import { getOrCreateDbSession } from '@/app/lib/sharedSessionManager';
// Note: We now use ephemeral key from /api/session instead of tenant config

// Global registry to track hook instances and prevent duplicates
const hookInstances = new Set<string>();
let hookInstanceCounter = 0;

interface UseSDKRealtimeSessionProps {
  agentConfig: AgentConfig;
  onMessage?: (message: UniversalMessage) => void;
  onError?: (error: Error) => void;
  sessionId: string;
  onAgentTransfer?: (agentName: string) => void;
  // Voice control options
  enabled?: boolean;
  acceptResponses?: boolean;
  muteAudio?: boolean;
  shouldAcceptResponseStart?: () => boolean;
  onUserVoiceItemCreated?: (initialText?: string) => void;
  // Response callbacks for UI updates
  onResponseStart?: () => void;
  onResponseStartFromDelta?: () => void;
  onResponseDelta?: (delta: string) => void;
  onResponseDone?: (text: string) => void;
  onTranscript?: (text: string) => void;
  onTranscriptDelta?: (delta: string) => void;
}

interface UseSDKRealtimeSessionReturn {
  session: RealtimeSession | null;
  isConnected: boolean;
  isConnecting: boolean;
  error: string | null;
  sendMessage: (message: string) => Promise<void>;
  startVoice: () => Promise<void>;
  stopVoice: () => void;
  disconnect: () => void;
  interrupt: () => void;
  isVoiceActive: boolean;
  isPTTActive: boolean;
  setIsPTTActive: (active: boolean) => void;
  isPTTUserSpeaking: boolean;
  mute: (mute: boolean) => void;
  // Test functions for development
  testFunctionCalls: () => Promise<void>;
  testModelResponseLogging: () => void;
}

/**
 * Clean SDK hook following App.tsx PTT pattern exactly
 * - Simple PTT with server VAD when idle (like App.tsx)
 * - Clean WebRTC handling
 * - UniversalMessage integration
 * - Database session management
 */
export function useSDKRealtimeSession({
  agentConfig,
  onMessage,
  onError,
  sessionId,
  onAgentTransfer,
  enabled = true,
  acceptResponses = true,
  muteAudio = false,
  shouldAcceptResponseStart,
  onUserVoiceItemCreated,
  onResponseStart,
  onResponseStartFromDelta,
  onResponseDelta,
  onResponseDone,
  onTranscript,
  onTranscriptDelta
}: UseSDKRealtimeSessionProps): UseSDKRealtimeSessionReturn {
  
  // Generate unique instance ID for debugging
  const instanceIdRef = useRef<string | null>(null);
  if (!instanceIdRef.current) {
    hookInstanceCounter++;
    instanceIdRef.current = `sdk-${hookInstanceCounter}`;
  }
  const instanceId = instanceIdRef.current;
  
  // Only log on initial hook creation, not on every render
  const hasLoggedInitRef = useRef(false);
  if (!hasLoggedInitRef.current) {
    console.log(`[SDK-${instanceId}] Hook initialized for agent: ${agentConfig.name}`);
    hasLoggedInitRef.current = true;
  }
  
  // Perform one-time registration
  const didRegisterRef = useRef(false);
  if (!didRegisterRef.current) {
    hookInstances.add(instanceId);
    didRegisterRef.current = true;
    console.log(`[SDK-${instanceId}] Hook mounted for agent: ${agentConfig.name}`);
  }
  
  const [session, setSession] = useState<RealtimeSession | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [isPTTActive, setIsPTTActive] = useState(true); // PTT mode enabled by default
  const [isPTTUserSpeaking, setIsPTTUserSpeaking] = useState(false);
  
  const agentWrapperRef = useRef<DatabaseAgentWrapper | null>(null);
  const sessionRef = useRef<RealtimeSession | null>(null);
  const dbSessionIdRef = useRef<string>('');
  const currentResponseRef = useRef<any>(null);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const allowAgentRunsRef = useRef<boolean>(false); // Flag to control when agent can run
  const hasAttemptedConnectionRef = useRef<boolean>(false); // Prevent multiple connection attempts
  const aiPlaceholderCreatedRef = useRef<boolean>(false); // Flag to prevent duplicate AI placeholders
  const userTranscriptionCompleteRef = useRef<boolean>(false); // Flag to track if user transcription is complete
  const microphoneMutedRef = useRef<boolean>(true); // Flag to track microphone mute state

  // Get API key from tenant configuration
  // Note: We now use ephemeral key from /api/session instead of tenant config

  // Initialize database session
  useEffect(() => {
    if (dbSessionIdRef.current) return;
    
    const initializeDbSession = async () => {
      try {
        const dbSessionId = await getOrCreateDbSession(sessionId, 'voice');
        dbSessionIdRef.current = dbSessionId;
        console.log('[SDK] ✅ Using session:', dbSessionId);
      } catch (err) {
        console.warn('[SDK] ❌ Failed to get session, using frontend session:', err);
        dbSessionIdRef.current = sessionId;
      }
    };
    
    initializeDbSession();
  }, [sessionId]);

  // Initialize agent wrapper when agent config changes
  useEffect(() => {
    if (!agentConfig.tools || agentConfig.tools.length === 0) {
      console.log('[SDK] ⚠️ No tools available for agent:', agentConfig.name);
      return;
    }
    
    // Check if we already have a wrapper for this agent to prevent duplicates
    if (agentWrapperRef.current && 
        agentWrapperRef.current.getAgentConfig().name === agentConfig.name &&
        JSON.stringify(agentWrapperRef.current.getAgentConfig().tools) === JSON.stringify(agentConfig.tools)) {
      console.log(`[SDK-${instanceId}] ✅ Agent wrapper already exists for: ${agentConfig.name} - skipping recreation`);
      return;
    }
    
    // Reset connection attempt flag when agent changes
    hasAttemptedConnectionRef.current = false;
    
    try {
      console.log(`[SDK-${instanceId}] 🔧 Creating agent wrapper for: ${agentConfig.name}`);
      agentWrapperRef.current = new DatabaseAgentWrapper(agentConfig, (message: string) => {
        const universalMessage: UniversalMessage = {
          id: `msg-${Date.now()}`,
          sessionId,
          timestamp: new Date().toISOString(),
          type: 'text',
          content: message,
          metadata: {
            source: 'ai',
            channel: 'realtime',
            language: 'en',
            agentName: agentConfig.name
          }
        };
        onMessage?.(universalMessage);
      });
      console.log(`[SDK-${instanceId}] ✅ Agent wrapper created for: ${agentConfig.name}`);
    } catch (err) {
      console.error(`[SDK-${instanceId}] ❌ Failed to create agent wrapper:`, err);
      setError(err instanceof Error ? err.message : 'Failed to create agent wrapper');
    }
  }, [agentConfig.name, agentConfig.tools]); // Removed onMessage and sessionId from deps to prevent unnecessary recreations

  // App.tsx style updateSession function - exact copy
  const updateSession = useCallback((shouldTriggerResponse: boolean = false) => {
    if (!sessionRef.current) return;
    
    // App.tsx: PTT active → null, PTT inactive → server_vad
    const turnDetection = isPTTActive
      ? null  // PTT active = no VAD
      : {     // PTT inactive = server VAD (open-mic mode)
          type: 'server_vad',
          threshold: 0.9,
          prefix_padding_ms: 300,
          silence_duration_ms: 500,
          create_response: true,
        };

    console.log('[SDK] 🎤 updateSession - turnDetection:', turnDetection ? 'server_vad' : 'disabled (PTT active)');
    console.log('[SDK] 🎤 updateSession - isPTTActive:', isPTTActive);
    
    try {
      (sessionRef.current as any).transport?.sendEvent?.({
        type: 'session.update',
        session: {
          turn_detection: turnDetection,
        },
      });
      console.log('[SDK] 🎤 updateSession - session.update sent successfully');
      
      // When PTT is active, aggressively clear any existing audio buffer
      if (isPTTActive) {
        console.log('[SDK] 🎤 PTT active - clearing audio buffer to prevent automatic processing');
        (sessionRef.current as any).transport?.sendEvent?.({ type: 'input_audio_buffer.clear' });
      }
    } catch (e) {
      console.warn('[SDK] Failed to update session:', e);
    }

    // Send initial 'hi' message to trigger agent greeting if requested
    if (shouldTriggerResponse) {
      console.log('[SDK] 🎤 Sending initial trigger message');
      // We don't auto-send 'hi' in our PTT mode
    }
  }, [isPTTActive]);

  // Connect to Realtime API using SDK
  const connect = useCallback(async () => {
    console.log(`[SDK-${instanceId}] 🔌 Connect function called, enabled:`, enabled);
    if (!enabled) {
      console.log(`[SDK-${instanceId}] SDK initialization disabled - skipping connection`);
      return;
    }
    
    if (hasAttemptedConnectionRef.current) {
      console.log(`[SDK-${instanceId}] ⚠️ Connection already attempted - skipping duplicate call`);
      return;
    }
    
    if (!agentWrapperRef.current) {
      setError('Agent wrapper not available');
      return;
    }
    
    hasAttemptedConnectionRef.current = true;

    setIsConnecting(true);
    setError(null);

    try {
      console.log('[SDK] Connecting to Realtime API with SDK...');
      
      // Create audio element for WebRTC
      const audioElement = document.createElement('audio');
      audioElement.autoplay = true;
      audioElement.muted = !!muteAudio;
      audioElement.style.display = 'none';
      document.body.appendChild(audioElement);
      audioElementRef.current = audioElement;
      
      console.log('[SDK] 🎵 Audio element created:', {
        autoplay: audioElement.autoplay,
        muted: audioElement.muted,
        readyState: audioElement.readyState,
        src: audioElement.src,
        srcObject: !!audioElement.srcObject
      });
      
      
      // Create SDK agent from wrapper
      const sdkAgent = agentWrapperRef.current.getSDKAgent();
      
      // Create transport (App.tsx pattern)
      const webRTCTransport = new OpenAIRealtimeWebRTC({
          audioElement,
          // Set preferred codec before offer creation (App.tsx pattern)
          changePeerConnection: async (pc: RTCPeerConnection) => {
            // Apply codec preferences like App.tsx
            return pc;
          },
      });
      
      console.log('[SDK] 🚀 WebRTC transport created:', {
        hasAudioElement: !!audioElement,
        audioElementSrc: audioElement.src,
        audioElementReadyState: audioElement.readyState,
        audioElementMuted: audioElement.muted,
        audioElementVolume: audioElement.volume
      });
      
      // App.tsx pattern: No manual audio track control - let WebRTC transport handle it automatically
      console.log('[SDK] 🎤 WebRTC transport will handle audio capture automatically (App.tsx pattern)');
      
      // Check if audio element is properly configured for WebRTC
      if (audioElement) {
        console.log('[SDK] 🎤 Audio element configuration:', {
          src: audioElement.src,
          readyState: audioElement.readyState,
          muted: audioElement.muted,
          volume: audioElement.volume,
          autoplay: audioElement.autoplay,
          controls: audioElement.controls
        });
      }
      
      // Check if transport has microphone access methods
      console.log('[SDK] 🚀 WebRTC transport methods:', {
        transportConstructor: webRTCTransport.constructor.name,
        transportProperties: Object.keys(webRTCTransport)
      });
      
      // Check if transport has audio capture capabilities
      console.log('[SDK] 🚀 WebRTC transport capabilities:', {
        hasGetUserMedia: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia),
        hasRTCPeerConnection: !!window.RTCPeerConnection,
        transportConstructor: webRTCTransport.constructor.name
      });
      

      // Create session with configuration (PTT-only mode)
      const newSession = new RealtimeSession(sdkAgent, {
        transport: webRTCTransport,
        model: 'gpt-4o-realtime-preview-2025-06-03',
        config: {
          inputAudioFormat: 'pcm16',
          outputAudioFormat: 'pcm16',
          inputAudioTranscription: {
            model: 'gpt-4o-mini-transcribe',
          },
          // PTT-only mode - disable VAD by default
          turnDetection: undefined
        }
      });
      
      console.log('[SDK] 🚀 Session created with config:', {
        model: 'gpt-4o-realtime-preview-2025-06-03',
        inputAudioFormat: 'pcm16',
        outputAudioFormat: 'pcm16',
        inputAudioTranscription: {
          model: 'gpt-4o-mini-transcribe',
        },
        turnDetection: 'undefined (PTT-only)'
      });
      
      // Check if session has the expected methods
      console.log('[SDK] 🚀 Session methods available:', {
        hasSendEvent: typeof (newSession as any).transport?.sendEvent === 'function',
        hasInterrupt: typeof (newSession as any).interrupt === 'function',
        hasTransport: !!(newSession as any).transport,
        transportType: (newSession as any).transport?.constructor?.name
      });
      
      (newSession as any).on('error', (err: any) => {
        console.error('[SDK] ❌ Session error:', err);
        console.error('[SDK] ❌ Session error details:', JSON.stringify(err, null, 2));
        if (err.error) {
          console.error('[SDK] ❌ Nested error:', JSON.stringify(err.error, null, 2));
        }
        setError(err.message || err.error?.message || 'Session error');
        onError?.(err);
      });

      (newSession as any).on('connect', () => {
        console.log('[SDK] ✅ Connected to Realtime API');
        console.log('[SDK] 🔌 Session connected - WebRTC transport should be ready');
        
        // Check if the transport has microphone access after connection
        const transport = (newSession as any).transport;
        if (transport) {
          console.log('[SDK] 🔌 Transport state after connection:', {
            state: transport.state,
            hasAudioTracks: transport.getAudioTracks ? transport.getAudioTracks().length : 'no method',
            transportType: transport.constructor.name
          });
        }
        
        setIsConnected(true);
        setIsConnecting(false);
        
        // App.tsx pattern: Call updateSession immediately after connection to set PTT mode
        console.log('[SDK] 🎤 Calling updateSession to set PTT mode after connection');
        updateSession();
        
        // App.tsx pattern: No manual microphone muting - let WebRTC transport handle it automatically
        console.log('[SDK] 🎤 WebRTC transport will handle microphone control automatically (App.tsx pattern)');
      });

      // Add general event logging to debug what events are being received
      (newSession as any).on('*', (eventName: any, data: any) => {
        const eventNameStr = String(eventName);
        if (eventNameStr.includes('transcription') || eventNameStr.includes('response') || eventNameStr.includes('agent')) {
          console.log(`[SDK] 📡 EVENT RECEIVED: ${eventNameStr}`, data);
        }
        if (eventNameStr.includes('error') || eventNameStr.includes('disconnect')) {
          console.error(`[SDK] ❌ ERROR/DISCONNECT EVENT: ${eventNameStr}`, data);
        }
      });

      // Add transport-level error logging
      if ((newSession as any).transport) {
        (newSession as any).transport.on('error', (err: any) => {
          console.error('[SDK] ❌ Transport error:', err);
          console.error('[SDK] ❌ Transport error details:', JSON.stringify(err, null, 2));
        });
        
        (newSession as any).transport.on('*', (eventName: any, data: any) => {
          const eventNameStr = String(eventName);
          if (eventNameStr.includes('error') || eventNameStr.includes('disconnect')) {
            console.error(`[SDK] ❌ TRANSPORT ERROR: ${eventNameStr}`, data);
          }
        });
      }

      (newSession as any).on('disconnect', () => {
        console.log('[SDK] 🔌 Disconnected from Realtime API');
        setIsConnected(false);
        setIsConnecting(false);
      });


      // Text response handling
      (newSession as any).on('response.text.delta', (data: any) => {
        console.log('[SDK] 📝 RESPONSE TEXT DELTA:', data);
        if (currentResponseRef.current && data.delta) {
          if (!currentResponseRef.current.content.find((c: any) => c.type === 'text')) {
            currentResponseRef.current.content.push({ type: 'text', content: '' });
          }
          const textContent = currentResponseRef.current.content.find((c: any) => c.type === 'text');
          if (textContent) {
            textContent.content += data.delta;
          }
        }
        if (acceptResponses && data.delta && onResponseDelta) {
          try { 
            console.log('[SDK] 📝 Calling onResponseDelta with text delta:', {
              delta: data.delta,
              length: data.delta.length,
              firstChar: data.delta ? data.delta[0] : 'none',
              placeholderCreated: aiPlaceholderCreatedRef.current
            });
            onResponseDelta(data.delta); 
          } catch (e) {
            console.error('[SDK] onResponseDelta error:', e);
          }
        }
      });

      (newSession as any).on('response.text.done', (data: any) => {
        console.log('[SDK] 🤖 RESPONSE TEXT DONE:', data.text);
        
        if (currentResponseRef.current) {
          const textContent = currentResponseRef.current.content.find((c: any) => c.type === 'text');
          if (textContent) {
            textContent.content = data.text;
            textContent.done = true;
          }
        }
        
        if (acceptResponses && data.text) {
          console.log('[SDK] 🤖 Creating AI message from text response:', data.text);
          const universalMessage: UniversalMessage = {
            id: `msg-${Date.now()}`,
            sessionId,
            timestamp: new Date().toISOString(),
            type: 'text',
            content: data.text,
            metadata: {
              source: 'ai',
              channel: 'realtime',
              language: 'en',
              agentName: agentConfig.name
            }
          };
          onMessage?.(universalMessage);
        }
        
        if (acceptResponses && data.text && onResponseDone) {
          try { 
            console.log('[SDK] 🤖 Calling onResponseDone with text:', data.text);
            onResponseDone(data.text); 
          } catch (e) {
            console.error('[SDK] onResponseDone error:', e);
          }
        }
      });

      // Listen for transport events (App.tsx pattern)
      (newSession as any).on('transport_event', (event: any) => {
        // console.log('[SDK] 📡 Transport event received:', event.type, event);
        
        switch (event.type) {
          case 'conversation.item.input_audio_transcription.completed': {
            console.log('[SDK] 🎤 VOICE TRANSCRIPTION COMPLETED:', event);
            console.log('[SDK] 🎤 Transcript text:', event.transcript);
            console.log('[SDK] 🎤 Full transcription data:', JSON.stringify(event, null, 2));
            
            // App.tsx pattern: Update existing user message with final transcript (replace, don't append)
            const itemId = event.item_id;
            const finalTranscript = event.transcript || "[inaudible]";
            
            if (itemId && onTranscript) {
              console.log('[SDK] 🎤 Updating user message with final transcription:', finalTranscript);
              // Send the complete transcript to replace the placeholder
              onTranscript(finalTranscript);
              // Mark user transcription as complete
              userTranscriptionCompleteRef.current = true;
            } else {
              console.log('[SDK] 🎤 No valid itemId or transcript found in event');
            }
            break;
          }
          case 'conversation.item.input_audio_transcription.delta': {
            console.log('[SDK] 🎤 VOICE TRANSCRIPTION DELTA:', event);
            console.log('[SDK] 🎤 Delta text:', event.delta);
            if (event.delta && onTranscriptDelta) {
              try { 
                console.log('[SDK] 🎤 Calling onTranscriptDelta with:', event.delta);
                onTranscriptDelta(event.delta); 
              } catch (e) {
                console.error('[SDK] onTranscriptDelta error:', e);
              }
            }
            break;
          }
          case 'conversation.item.input_audio_transcription.failed': {
            console.warn('[SDK] 🎤 TRANSCRIPTION FAILED:', event);
            break;
          }
          case 'response.audio_transcript.delta': {
            // console.log('[SDK] 🎤 RESPONSE AUDIO TRANSCRIPT DELTA:', event);
            // App.tsx pattern: Update existing AI message with delta (append=true)
            const itemId = event.item_id;
            const deltaText = event.delta || "";
            
            if (itemId && deltaText) {
              // App.tsx pattern: Create AI placeholder on first delta if it doesn't exist
              // For text input, don't wait for user transcription - create placeholder immediately
              if (onResponseStartFromDelta && !aiPlaceholderCreatedRef.current) {
                try {
                  console.log('[SDK] 🎤 Creating AI placeholder on first response delta');
                  // Initialize currentResponseRef if it doesn't exist
                  if (!currentResponseRef.current) {
                    currentResponseRef.current = {
                      id: `response-${Date.now()}`,
                      type: 'audio_transcript',
                      created_at: new Date().toISOString(),
                      content: [],
                      placeholderCreated: false
                    };
                  }
                  onResponseStartFromDelta();
                  aiPlaceholderCreatedRef.current = true;
                  if (currentResponseRef.current) {
                    currentResponseRef.current.placeholderCreated = true;
                  }
                } catch (e) {
                  console.error('[SDK] onResponseStartFromDelta error in delta handler:', e);
                }
              }
              
              // Update AI message with delta
              if (onResponseDelta) {
                try { 
                  // console.log('[SDK] 🎤 Updating AI message with response transcript delta:', {
                  //   delta: deltaText,
                  //   length: deltaText.length,
                  //   firstChar: deltaText ? deltaText[0] : 'none',
                  //   placeholderCreated: aiPlaceholderCreatedRef.current
                  // });
                  onResponseDelta(deltaText);
                } catch (e) {
                  console.error('[SDK] response.audio_transcript.delta error:', e);
                }
              }
            }
            break;
          }
          case 'response.audio_transcript.done': {
            console.log('[SDK] 🎤 RESPONSE AUDIO TRANSCRIPT DONE:', event);
            // App.tsx pattern: Update existing AI message with final transcript (replace, don't append)
            const itemId = event.item_id;
            const finalTranscript = event.transcript || "[inaudible]";
            
            if (itemId && finalTranscript && onResponseDone) {
              try { 
                console.log('[SDK] 🎤 Updating AI message with final response transcript:', finalTranscript);
                onResponseDone(finalTranscript);
              } catch (e) {
                console.error('[SDK] response.audio_transcript.done error:', e);
              }
            }
            break;
          }
          case 'response.audio.delta': {
            console.log('[SDK] 🔊 RESPONSE AUDIO DELTA:', event);
            // Handle audio playback delta
            if (audioElementRef.current && event.delta) {
              try {
                // The audio delta should be handled by the WebRTC transport automatically
                console.log('[SDK] 🔊 Audio delta received, length:', event.delta.length);
              } catch (e) {
                console.error('[SDK] response.audio.delta error:', e);
              }
            }
            break;
          }
          case 'response.audio.done': {
            console.log('[SDK] 🔊 RESPONSE AUDIO DONE:', event);
            // Handle audio playback completion
            if (audioElementRef.current) {
              try {
                console.log('[SDK] 🔊 Audio response completed');
              } catch (e) {
                console.error('[SDK] response.audio.done error:', e);
              }
            }
            break;
          }
        }
      });

      // Response events are now handled in the transport_event handler above


      // Function call handling
      (newSession as any).on('function_call', async (call: any) => {
        console.log('[SDK] 🔧 Function call received:', call);
        console.log('[SDK] 🔧 Function call name:', call.name);
        console.log('[SDK] 🔧 Function call parameters:', call.parameters);
        
        if (!allowAgentRunsRef.current) {
          // Block any automatic tool execution and cancel the pending response
          try {
            console.log('[SDK] 🔧 Blocking function_call (no user interaction); sending response.cancel');
            (sessionRef.current as any)?.transport?.sendEvent?.({ type: 'response.cancel' });
        } catch {}
          return;
        }
        
        // Handle transferAgents specially
        if (call.name === 'transferAgents') {
          const destination = call.parameters?.destination_agent;
          if (destination && onAgentTransfer) {
            console.log(`[SDK] 🔁 Transferring to agent: ${destination}`);
            onAgentTransfer(destination);
          }
        }
      });

      // Response lifecycle management
      (newSession as any).on('response.created', (data: any) => {
        console.log('[SDK] 📋 RESPONSE CREATED:', data);
        console.log('[SDK] 📋 Response created - resetting flags for new response');
        currentResponseRef.current = {
          id: data.id,
          type: data.type,
          created_at: data.created_at,
          content: []
        };
        // Reset placeholder creation flag for new response
        aiPlaceholderCreatedRef.current = false;
        
        // Only block if no user interaction allowed - allow responses after PTT usage
        if (!allowAgentRunsRef.current) {
          try {
            console.log('[SDK] 📋 Auto-canceling response (no user interaction yet)');
            (sessionRef.current as any)?.transport?.sendEvent?.({ type: 'response.cancel' });
          } catch (e) {
            console.warn('[SDK] 📋 Auto-cancel failed', e);
          }
          return;
        }
        
        console.log('[SDK] 📋 Response created - checking if should create AI placeholder:', {
          acceptResponses,
          shouldAcceptResponseStart: shouldAcceptResponseStart ? shouldAcceptResponseStart() : 'no function',
          onResponseStart: !!onResponseStart
        });
        
        if (acceptResponses && (!shouldAcceptResponseStart || shouldAcceptResponseStart()) && onResponseStart) {
          try { 
            console.log('[SDK] 📋 Creating AI placeholder for response');
            onResponseStart(); 
          } catch (e) {
            console.error('[SDK] onResponseStart error:', e);
          }
        }
      });

      (newSession as any).on('response.done', (data: any) => {
        console.log('[SDK] 📋 RESPONSE DONE:', data);
        if (currentResponseRef.current) {
          currentResponseRef.current = null;
        }
        // Reset placeholder creation flag for next response
        aiPlaceholderCreatedRef.current = false;
        // Notify UI that response is done
        if (onResponseDone) {
          try { onResponseDone(''); } catch (e) {
            console.error('[SDK] onResponseDone error:', e);
          }
        }
      });

      // Add agent events with proper PTT-aware blocking
      (newSession as any).on('agent_start', (data: any) => {
        // Only block if no user interaction allowed - allow agent runs after PTT usage
        if (!allowAgentRunsRef.current) {
          console.log('[SDK] 🚫 AGENT START BLOCKED - no user interaction yet:', data);
          try { 
            // Only clear audio buffer - don't cancel response unless there's an active one
            (sessionRef.current as any)?.transport?.sendEvent?.({ type: 'input_audio_buffer.clear' }); 
          } catch {}
          return;
        }
        console.log('[SDK] 🤖 AGENT START:', data);
      });

      (newSession as any).on('agent_end', (data: any) => {
        // Only block if no user interaction allowed - allow agent runs after PTT usage
        if (!allowAgentRunsRef.current) {
          console.log('[SDK] 🚫 AGENT END BLOCKED - no user interaction yet:', data);
          try { 
            // Only clear audio buffer - don't cancel response unless there's an active one
            (sessionRef.current as any)?.transport?.sendEvent?.({ type: 'input_audio_buffer.clear' }); 
        } catch {}
          return;
        }
        console.log('[SDK] 🤖 AGENT END:', data);
      });

      // Block any automatic response creation
      (newSession as any).on('response.create', (data: any) => {
        // Only block if no user interaction allowed - allow responses after PTT usage
        if (!allowAgentRunsRef.current) {
          console.log('[SDK] 🚫 RESPONSE CREATE BLOCKED - no user interaction yet:', data);
          try { 
            // Only clear audio buffer - don't cancel response unless there's an active one
            (sessionRef.current as any)?.transport?.sendEvent?.({ type: 'input_audio_buffer.clear' }); 
          } catch {}
          return;
        }
        console.log('[SDK] 🤖 RESPONSE CREATE:', data);
      });

      // User voice item creation
      (newSession as any).on('conversation.item.created', (data: any) => {
        try {
          const role = data?.item?.role;
          const type = data?.item?.type;
          const text = data?.item?.content?.[0]?.text || data?.item?.content?.[0]?.transcript || '';
          if (role === 'user' || type === 'input_audio') {
            console.log('[SDK] ◀ conversation.item.created (user/input_audio):', text);
            onUserVoiceItemCreated?.(typeof text === 'string' ? text : undefined);
          }
        } catch {}
      });

      // App.tsx style: Get ephemeral key from /api/session endpoint
      console.log('[SDK] 🔑 Fetching ephemeral key from /api/session...');
      
      let ephemeralKey: string;
      try {
        const tokenResponse = await fetch('/api/session');
        const data = await tokenResponse.json();
        
        if (!data.client_secret?.value) {
          throw new Error('No ephemeral key provided by the server');
        }
        
        ephemeralKey = data.client_secret.value;
        console.log('[SDK] 🔑 Ephemeral key obtained:', ephemeralKey ? 'Success' : 'Failed');
      } catch (err) {
        console.error('[SDK] ❌ Failed to get ephemeral key:', err);
        setError('Failed to get ephemeral key from server');
        setIsConnecting(false);
        setIsConnected(false);
        onError?.(err instanceof Error ? err : new Error('Failed to get ephemeral key'));
        return;
      }
      
      try {
        console.log('[SDK] 🔌 Attempting to connect with ephemeral key...');
        const connectionPromise = newSession.connect({ apiKey: ephemeralKey });
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Connection timeout')), 10000)
        );
        
        await Promise.race([connectionPromise, timeoutPromise]);
        console.log('[SDK] ✅ Real API connection successful with ephemeral key');
      } catch (err: any) {
        console.error('[SDK] ❌ Real API connection failed:', err?.message || err);
        console.error('[SDK] ❌ Connection error details:', JSON.stringify(err, null, 2));
        if (err instanceof Error) {
          console.error('[SDK] ❌ Error message:', err.message);
          console.error('[SDK] ❌ Error stack:', err.stack);
        }
        setError(`Connection failed: ${err?.message || 'Unknown error'}`);
          setIsConnecting(false);
        setIsConnected(false);
        onError?.(err instanceof Error ? err : new Error('Connection failed'));
        return;
      }
      
      sessionRef.current = newSession;
      setSession(newSession);
      
      // Set connection state after successful connection
      setIsConnected(true);
      setIsConnecting(false);
      console.log('[SDK] ✅ Connection established successfully');
      
      // App.tsx pattern: Call updateSession immediately after connection to set PTT mode
      console.log('[SDK] 🎤 Calling updateSession to set PTT mode after connection');
      updateSession();

    } catch (err) {
      console.error('[SDK] Connection failed:', err);
      setIsConnecting(false);
      setError(err instanceof Error ? err.message : 'Connection failed');
      onError?.(err instanceof Error ? err : new Error('Connection failed'));
    }
  }, [agentConfig, onMessage, onError, onAgentTransfer, sessionId, enabled, acceptResponses, muteAudio, shouldAcceptResponseStart, onUserVoiceItemCreated, onResponseStart, onResponseDelta, onResponseDone, onTranscript, onTranscriptDelta]);

  // React to muteAudio changes
  useEffect(() => {
    if (audioElementRef.current) {
      audioElementRef.current.muted = !!muteAudio;
    }
  }, [muteAudio]);

  // Send message through SDK session
  const sendMessage = useCallback(async (message: string) => {
    if (!sessionRef.current || !isConnected) {
      setError('Session not connected');
      return;
    }

    try {
      console.log('[SDK] 📤 Sending message:', message);
      
      // Enable agent runs when user sends a message
      allowAgentRunsRef.current = true;
      console.log('[SDK] ✅ Agent runs enabled for user interaction');
      
      // For text input, mark user transcription as complete immediately
      userTranscriptionCompleteRef.current = true;
      console.log('[SDK] 📝 Text input - marking user transcription as complete');
      
      // Add user message to chat
      const userMessage: UniversalMessage = {
        id: `msg-${Date.now()}`,
        sessionId,
        timestamp: new Date().toISOString(),
        type: 'text',
        content: message,
        metadata: {
          source: 'user',
          channel: 'realtime',
          language: 'en'
        }
      };
      
      onMessage?.(userMessage);
      
      // Send through SDK
      await (sessionRef.current as any).sendMessage(message);
      
      // Log to database
      try {
        await fetch('/api/log/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            session_id: dbSessionIdRef.current,
            role: 'user',
            type: 'text',
            content: message,
            channel: 'realtime',
            meta: { is_internal: false }
          })
        });
    } catch (err) {
        console.warn('[SDK] Failed to log user message:', err);
      }
      
    } catch (err) {
      console.error('[SDK] Failed to send message:', err);
      setError(err instanceof Error ? err.message : 'Failed to send message');
      onError?.(err instanceof Error ? err : new Error('Failed to send message'));
    }
  }, [isConnected, onMessage, onError, sessionId]);

  // App.tsx style PTT button down handler - exact copy
  const startVoice = useCallback(async () => {
    if (!sessionRef.current || !isConnected) {
      setError('Session not connected');
      return;
    }

    console.log('[SDK] 🎤 PTT BUTTON DOWN - App.tsx style');
    
    // Enable agent runs when user starts voice input
    allowAgentRunsRef.current = true;
    console.log('[SDK] ✅ Agent runs enabled for voice interaction');
    
    // Reset flags for new PTT session
    userTranscriptionCompleteRef.current = false;
    aiPlaceholderCreatedRef.current = false;
    
    // App.tsx pattern: interrupt + clear buffer + set speaking state
    try {
      (sessionRef.current as any).interrupt?.();
      console.log('[SDK] 🎤 Interrupted session (App.tsx pattern)');
    } catch (err) {
      console.error('[SDK] ❌ Failed to interrupt session:', err);
    }

    try {
      (sessionRef.current as any).transport?.sendEvent?.({ type: 'input_audio_buffer.clear' });
      console.log('[SDK] 🎤 Clearing input audio buffer (App.tsx pattern)');
      
      // Check if WebRTC transport is ready to capture audio
      const transport = (sessionRef.current as any).transport;
      if (transport && transport.peerConnection) {
        console.log('[SDK] 🎤 Checking WebRTC audio capture after buffer clear...');
        const senders = transport.peerConnection.getSenders();
        const audioSenders = senders.filter((sender: any) => sender.track && sender.track.kind === 'audio');
        
        console.log('[SDK] 🎤 WebRTC audio senders after clear:', audioSenders.length);
        
        if (audioSenders.length === 0) {
          console.error('[SDK] ❌ No audio senders found! WebRTC is not ready to capture audio!');
          console.log('[SDK] 🎤 All senders:', senders.map((s: any) => ({ kind: s.track?.kind, enabled: s.track?.enabled })));
        } else {
          audioSenders.forEach((sender: any, index: number) => {
            const track = sender.track;
            console.log(`[SDK] 🎤 Audio sender ${index} after clear:`, {
              enabled: track.enabled,
              muted: track.muted,
              readyState: track.readyState,
              label: track.label
            });
          });
        }
      }
      
      // App.tsx pattern: No manual microphone control - let WebRTC transport handle it automatically
      console.log('[SDK] 🎤 WebRTC transport will handle microphone capture automatically (App.tsx pattern)');
      
      // Check if microphone is actually enabled after clearing buffer
      setTimeout(() => {
        const transport = (sessionRef.current as any).transport;
        if (transport) {
          console.log('[SDK] 🎤 Checking microphone state after buffer clear...');
          console.log('[SDK] 🎤 Transport type:', transport.constructor.name);
          console.log('[SDK] 🎤 Transport state:', transport.state);
          
          // Check WebRTC peer connection state
          if (transport.peerConnection) {
            console.log('[SDK] 🎤 WebRTC peer connection state:', transport.peerConnection.connectionState);
            console.log('[SDK] 🎤 WebRTC ICE connection state:', transport.peerConnection.iceConnectionState);
            
            // Check audio tracks in WebRTC
            const senders = transport.peerConnection.getSenders();
            const audioSenders = senders.filter((sender: any) => sender.track && sender.track.kind === 'audio');
            console.log('[SDK] 🎤 WebRTC audio senders:', audioSenders.length);
            
            audioSenders.forEach((sender: any, index: number) => {
              const track = sender.track;
              console.log(`[SDK] 🎤 WebRTC Audio sender ${index}:`, {
                enabled: track.enabled,
                muted: track.muted,
                readyState: track.readyState,
                label: track.label,
                id: track.id
              });
            });
          }
          
          // Check if we can access the microphone directly
          if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ audio: true })
              .then(stream => {
                console.log('[SDK] 🎤 Direct microphone access test:', {
                  streamActive: stream.active,
                  audioTracks: stream.getAudioTracks().length,
                  trackStates: stream.getAudioTracks().map(track => ({
                    enabled: track.enabled,
                    muted: track.muted,
                    readyState: track.readyState,
                    label: track.label
                  }))
                });
                stream.getTracks().forEach(track => track.stop()); // Clean up
              })
              .catch(err => {
                console.error('[SDK] ❌ Direct microphone access failed:', err);
              });
          }
        }
      }, 1000); // Check after 1 second
    } catch (err) {
      console.error('[SDK] ❌ Failed to send input_audio_buffer.clear:', err);
    }
    
    setIsPTTUserSpeaking(true);
    setIsVoiceActive(true);
    
    console.log('[SDK] 🎤 Voice input successfully started');
  }, [isConnected, onError]);

  // App.tsx style PTT button up handler - exact copy
  const stopVoice = useCallback(() => {
    if (!sessionRef.current || !isPTTUserSpeaking) {
      console.warn('[SDK] 🎤 stopVoice called but no session or not speaking');
      return;
    }

    console.log('[SDK] 🎤 PTT BUTTON UP - App.tsx style');
    
    // Check if we have audio in the buffer before committing
    const transport = (sessionRef.current as any).transport;
    if (transport && transport.peerConnection) {
      console.log('[SDK] 🎤 Checking WebRTC audio capture before commit...');
      const senders = transport.peerConnection.getSenders();
      const audioSenders = senders.filter((sender: any) => sender.track && sender.track.kind === 'audio');
      
      console.log('[SDK] 🎤 WebRTC audio senders before commit:', audioSenders.length);
      
      if (audioSenders.length === 0) {
        console.error('[SDK] ❌ No audio senders found! WebRTC is not capturing audio!');
        console.log('[SDK] 🎤 All senders:', senders.map((s: any) => ({ kind: s.track?.kind, enabled: s.track?.enabled })));
        setIsPTTUserSpeaking(false);
        return; // Don't commit empty buffer
      } else {
        audioSenders.forEach((sender: any, index: number) => {
          const track = sender.track;
          console.log(`[SDK] 🎤 Audio sender ${index} before commit:`, {
            enabled: track.enabled,
            muted: track.muted,
            readyState: track.readyState,
            label: track.label
          });
        });
      }
    }
    
    // Add a small delay to ensure we have some audio before committing
    // This prevents the "buffer too small" error
    setTimeout(() => {
      // App.tsx pattern: commit buffer + create response + set speaking state to false
      try {
        (sessionRef.current as any).transport?.sendEvent?.({ type: 'input_audio_buffer.commit' });
        console.log('[SDK] 🎤 Committing input audio buffer (App.tsx pattern)');
      } catch (err) {
        console.error('[SDK] ❌ Failed to send input_audio_buffer.commit:', err);
      }
      
      try {
        (sessionRef.current as any).transport?.sendEvent?.({ type: 'response.create' });
        console.log('[SDK] 🎤 Triggering response (App.tsx pattern)');
      } catch (err) {
        console.error('[SDK] ❌ Failed to send response.create:', err);
      }
      
      // App.tsx pattern: Set speaking state to false (no manual microphone control)
      setIsPTTUserSpeaking(false);
      console.log('[SDK] 🎤 Voice input successfully stopped');
    }, 100); // Small delay to ensure audio is captured
    
    // Check if we get any events after this
    setTimeout(() => {
      console.log('[SDK] 🎤 2 seconds after buffer commit - checking for events...');
      
      // Check if WebRTC transport is receiving audio data
      const transport = (sessionRef.current as any).transport;
      if (transport && transport.peerConnection) {
        console.log('[SDK] 🎤 Checking WebRTC audio data flow...');
        
        // Check if there are any active audio tracks
        const senders = transport.peerConnection.getSenders();
        const audioSenders = senders.filter((sender: any) => sender.track && sender.track.kind === 'audio');
        
        if (audioSenders.length > 0) {
          console.log('[SDK] 🎤 WebRTC has active audio senders:', audioSenders.length);
          
          // Try to get audio buffer info if available
          if (typeof transport.getAudioBufferInfo === 'function') {
            try {
              const bufferInfo = transport.getAudioBufferInfo();
              console.log('[SDK] 🎤 Audio buffer info after commit:', bufferInfo);
            } catch (err) {
              console.log('[SDK] 🎤 Could not get audio buffer info:', err);
            }
          }
        } else {
          console.log('[SDK] 🎤 No active audio senders found in WebRTC');
        }
      }
    }, 2000);
    
    // Add a delay to ensure audio was captured before committing
    setTimeout(() => {
      console.log('[SDK] 🎤 5 seconds after PTT - checking if we got any transcription events...');
    }, 5000);
    
    // Set speaking state to false after committing (App.tsx pattern)
    setIsPTTUserSpeaking(false);
    setIsVoiceActive(false);

    console.log('[SDK] 🎤 Voice input successfully stopped');
  }, [isPTTUserSpeaking, onError]);

  // Disconnect session
  const disconnect = useCallback(() => {
    if (!sessionRef.current) return;

    try {
      console.log('[SDK] Disconnecting session...');
      const s: any = sessionRef.current as any;
      
      // App.tsx pattern: No manual cleanup needed - WebRTC transport handles it
      
      if (typeof s.disconnect === 'function') {
        s.disconnect();
      } else if (typeof s.close === 'function') {
        s.close();
      } else if (typeof s.transport?.close === 'function') {
        s.transport.close();
      } else {
        console.warn('[SDK] No disconnect/close method available on session');
      }
      sessionRef.current = null;
      setSession(null);
      setIsConnected(false);
      setIsVoiceActive(false);
    } catch (err) {
      console.error('[SDK] Failed to disconnect:', err);
      setError(err instanceof Error ? err.message : 'Failed to disconnect');
    }
  }, []);

  // Test function to force function calls
  const testFunctionCalls = useCallback(async () => {
    if (!sessionRef.current || !isConnected) {
      setError('Session not connected');
      return;
    }

    try {
      console.log('[SDK] 🧪 Testing function calls...');
      const testMessage = "I need to transfer to the placeGuide agent because I want to find nearby restaurants.";
      await (sessionRef.current as any).sendMessage(testMessage);
    } catch (err) {
      console.error('[SDK] Failed to test function calls:', err);
      setError(err instanceof Error ? err.message : 'Failed to test function calls');
    }
  }, [isConnected]);

  // Test function to demonstrate model response logging
  const testModelResponseLogging = useCallback(() => {
    console.log('[SDK] 🧪 Demonstrating model response logging...');
    
    const mockResponse = {
      id: 'resp_demo_123',
      type: 'response',
      created_at: new Date().toISOString(),
      content: [
        {
          type: 'text',
          content: 'Hello! I\'m a travel assistant. How can I help you today?',
          done: true
        }
      ]
    };

    console.log('[SDK] 🤖 MOCK MODEL RESPONSE:', JSON.stringify(mockResponse, null, 2));
  }, []);

  // App.tsx style: Update session when PTT state changes
  useEffect(() => {
    if (isConnected) {
      console.log('[SDK] 🎤 PTT state changed, updating session (App.tsx pattern)');
      updateSession();
      
      // Let WebRTC transport handle audio capture automatically (App.tsx pattern)
      if (isPTTActive) {
        console.log('[SDK] 🎤 PTT active - WebRTC transport will handle audio capture automatically');
        // No manual microphone control needed - let WebRTC transport handle it
      } else {
        console.log('[SDK] 🎤 PTT inactive - WebRTC transport will handle audio capture automatically');
        // No manual microphone control needed - let WebRTC transport handle it
      }
    }
  }, [isPTTActive, isConnected, updateSession]);

  // Auto-connect when dependencies are ready
  useEffect(() => {
    if (enabled && 
        agentWrapperRef.current && 
        !isConnected && 
        !isConnecting &&
        agentConfig.tools && 
        agentConfig.tools.length > 0) {
      
      console.log(`[SDK-${instanceId}] 🔌 Auto-connecting to voice service...`);
        connect();
    }
  }, [enabled, isConnected, isConnecting, agentConfig.tools?.length, connect, instanceId]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      // Remove from registry
      hookInstances.delete(instanceId);
      console.log(`[SDK-${instanceId}] 🧹 Hook instance cleaned up`);
      disconnect();
    };
  }, [disconnect, instanceId]);

  // Mute function for client-side microphone control
  const mute = useCallback((mute: boolean) => {
    if (sessionRef.current && (sessionRef.current as any).mute) {
      try {
        (sessionRef.current as any).mute(mute);
        console.log('[SDK] 🎤 Microphone muted:', mute);
      } catch (e) {
        console.warn('[SDK] Failed to mute microphone:', e);
      }
    }
  }, []);

  // App.tsx style interrupt function
  const interrupt = useCallback(() => {
    if (sessionRef.current) {
      try {
        (sessionRef.current as any).interrupt?.();
        console.log('[SDK] 🛑 Interrupted session');
      } catch (e) {
        console.warn('[SDK] Failed to interrupt:', e);
      }
    }
  }, []);

  return {
    session,
    isConnected,
    isConnecting,
    error,
    sendMessage,
    startVoice,
    stopVoice,
    disconnect,
    interrupt,
    isVoiceActive,
    isPTTActive,
    setIsPTTActive,
    isPTTUserSpeaking,
    mute,
    testFunctionCalls,
    testModelResponseLogging
  };
}