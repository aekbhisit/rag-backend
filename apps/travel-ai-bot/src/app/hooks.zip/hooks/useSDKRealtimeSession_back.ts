import { useState, useEffect, useRef, useCallback } from 'react';
import { RealtimeSession, OpenAIRealtimeWebRTC, RealtimeAgent } from '@openai/agents/realtime';
import { DatabaseAgentWrapper } from '@/app/lib/sdk-agent-wrapper';
import { AgentConfig } from '@/app/types';
import { UniversalMessage } from '@/app/types';
import { getOrCreateDbSession } from '@/app/lib/sharedSessionManager';

// Global registry to track hook instances and prevent duplicates
const hookInstances = new Set<string>();
let hookInstanceCounter = 0;
// Track one primary hook instance per agent name across renders/mounts
const primaryInstanceForAgent = new Map<string, string>();

interface UseSDKRealtimeSessionProps {
  agentConfig: AgentConfig;
  getEphemeralKey: () => Promise<string>;
  onMessage?: (message: UniversalMessage) => void;
  onError?: (error: Error) => void;
  sessionId: string;
  onAgentTransfer?: (agentName: string) => void;
  // Voice control options
  enabled?: boolean;
  acceptResponses?: boolean;
  muteAudio?: boolean;
  shouldAcceptResponseStart?: () => boolean;
  onUserVoiceItemCreated?: (initialText?: string) => void;
  // Response callbacks for UI updates
  onResponseStart?: () => void;
  onResponseDelta?: (delta: string) => void;
  onResponseDone?: (text: string) => void;
  onTranscript?: (text: string) => void;
  onTranscriptDelta?: (delta: string) => void;
}

interface UseSDKRealtimeSessionReturn {
  session: RealtimeSession | null;
  isConnected: boolean;
  isConnecting: boolean;
  error: string | null;
  sendMessage: (message: string) => Promise<void>;
  startVoice: () => Promise<void>;
  stopVoice: () => void;
  disconnect: () => void;
  isVoiceActive: boolean;
  // Test functions for development
  testFunctionCalls: () => Promise<void>;
  testModelResponseLogging: () => void;
}

/**
 * SDK hook that provides comprehensive Realtime API integration
 * - Comprehensive WebRTC handling with push-to-talk
 * - Clean UniversalMessage integration
 * - Database session management
 * - Agent transfer handling
 * - Extensive debugging and error recovery
 */
export function useSDKRealtimeSession({
  agentConfig,
  getEphemeralKey,
  onMessage,
  onError,
  sessionId,
  onAgentTransfer,
  enabled = true,
  acceptResponses = true,
  muteAudio = false,
  shouldAcceptResponseStart,
  onUserVoiceItemCreated,
  onResponseStart,
  onResponseDelta,
  onResponseDone,
  onTranscript,
  onTranscriptDelta
}: UseSDKRealtimeSessionProps): UseSDKRealtimeSessionReturn {
  
  // Generate unique instance ID for debugging
  const instanceIdRef = useRef<string | null>(null);
  if (!instanceIdRef.current) {
    hookInstanceCounter++;
    instanceIdRef.current = `sdk-${hookInstanceCounter}`;
  }
  const instanceId = instanceIdRef.current;
  
  // Only log on initial hook creation, not on every render
  const hasLoggedInitRef = useRef(false);
  if (!hasLoggedInitRef.current) {
    const stackTrace = new Error().stack;
    console.log(`[SDK-${instanceId}] Hook initialized for agent: ${agentConfig.name}`);
    console.log(`[SDK-${instanceId}] Hook call stack:`, stackTrace);
    hasLoggedInitRef.current = true;
  }
  
  // Perform one-time registration and determine primary per agent
  const didRegisterRef = useRef(false);
  if (!didRegisterRef.current) {
    hookInstances.add(instanceId);
    didRegisterRef.current = true;
    console.log(`[SDK-${instanceId}] Hook mounted for agent: ${agentConfig.name}`);
  }

  // Use a ref to track if this is the primary instance for this agent
  const isPrimaryInstanceRef = useRef<boolean | null>(null);
  if (isPrimaryInstanceRef.current === null) {
    const existingPrimary = primaryInstanceForAgent.get(agentConfig.name);
    if (!existingPrimary) {
      primaryInstanceForAgent.set(agentConfig.name, instanceId);
      isPrimaryInstanceRef.current = true;
      console.log(`[SDK-${instanceId}] 🏷️ Registered PRIMARY instance for agent: ${agentConfig.name}`);
    } else {
      isPrimaryInstanceRef.current = existingPrimary === instanceId;
      if (!isPrimaryInstanceRef.current) {
        console.log(`[SDK-${instanceId}] ⚠️ Secondary/duplicate hook instance for agent: ${agentConfig.name}`);
      }
    }
  }
  
  const [session, setSession] = useState<RealtimeSession | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [isPTTUserSpeaking, setIsPTTUserSpeaking] = useState(false);
  
  const agentWrapperRef = useRef<DatabaseAgentWrapper | null>(null);
  const sessionRef = useRef<RealtimeSession | null>(null);
  const dbSessionIdRef = useRef<string>('');
  const currentResponseRef = useRef<any>(null);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const transcriptAwaitingRef = useRef<boolean>(false);
  const transcriptReceivedRef = useRef<boolean>(false);
  const transcriptTimeoutHandleRef = useRef<any>(null);
  const hasAttemptedConnectionRef = useRef<boolean>(false);
  const allowAgentRunsRef = useRef<boolean>(false); // Flag to control when agent can run

  // Debug/diagnostic refs
  const sessionUpdateSeqRef = useRef<number>(0);
  const lastSentTurnDetectionRef = useRef<any>(null);
  const lastServerTurnDetectionRef = useRef<any>(null);
  const connectionEstablishedAtRef = useRef<number | null>(null);

  const logTransportState = useCallback((label: string) => {
    try {
      const s: any = sessionRef.current as any;
      const transport: any = s?.transport;
      const pc: RTCPeerConnection | undefined = transport?.pc || transport?.peerConnection;
      const senders = pc?.getSenders ? pc.getSenders() : [];
      const audioSenders = (senders || []).filter((sndr: RTCRtpSender) => sndr.track && sndr.track.kind === 'audio');
      const localStream: MediaStream | undefined = transport?.localStream || transport?.inputStream || transport?.microphoneStream;
      const tracks = localStream?.getTracks?.() || [];
      console.log('[SDK] 🔎 TRANSPORT STATE –', label, {
        connected: isConnected,
        isVoiceActive,
        pcExists: !!pc,
        senderCount: senders?.length || 0,
        audioSenderCount: audioSenders.length,
        hasLocalStream: !!localStream,
        localTrackCount: tracks.length,
        localTracks: tracks.map(t => ({ id: t.id, kind: t.kind, enabled: t.enabled, readyState: (t as any)?.readyState }))
      });
    } catch (e) {
      console.warn('[SDK] 🔎 Failed to log transport state:', e);
    }
  }, [isConnected, isVoiceActive]);

  const sendTurnDetection = useCallback((turnDetection: any, reason: string) => {
    const seq = ++sessionUpdateSeqRef.current;
    const payload = {
      type: 'session.update',
      session: { turn_detection: turnDetection }
    };
    lastSentTurnDetectionRef.current = { seq, reason, turnDetection, at: Date.now(), stack: new Error().stack };
    console.log('[SDK] 📡 SENDING session.update', { seq, reason, turnDetection });
    try {
      (sessionRef.current as any)?.sendEvent?.(payload);
    } catch (e) {
      console.warn('[SDK] 📡 session.update send failed', e);
    }
  }, []);

  // App.tsx style updateSession function
  const updateSession = useCallback((shouldTriggerResponse: boolean = false) => {
    if (!sessionRef.current) return;
    
    // STRICT PTT: Always null (no open-mic, no server VAD)
    const turnDetection = null;
    
    console.log('[SDK] 🎤 updateSession - turnDetection: disabled (STRICT PTT)');
    sendTurnDetection(turnDetection, 'updateSession');

    // App.tsx: Send initial 'hi' message to trigger agent greeting if requested
    if (shouldTriggerResponse) {
      console.log('[SDK] 🎤 Sending initial trigger message');
      // We don't auto-send 'hi' in our PTT-only mode
    }
  }, [isVoiceActive]);

  // Initialize database session
  useEffect(() => {
    // Skip if this is a duplicate instance
    if (isPrimaryInstanceRef.current !== true) {
      console.log(`[SDK-${instanceId}] ⚠️ Skipping database session initialization - duplicate instance`);
      return;
    }
    
    // Skip if we already have a session ID
    if (dbSessionIdRef.current) {
      console.log(`[SDK-${instanceId}] ✅ Database session already initialized: ${dbSessionIdRef.current}`);
      return;
    }
    
    const initializeDbSession = async () => {
      try {
        const dbSessionId = await getOrCreateDbSession(sessionId, 'voice');
        dbSessionIdRef.current = dbSessionId;
        console.log(`[SDK-${instanceId}] ✅ Using session: ${dbSessionId} for voice mode`);
      } catch (err) {
        console.warn(`[SDK-${instanceId}] ❌ Failed to get session, using frontend session:`, err);
        dbSessionIdRef.current = sessionId;
      }
    };
    
    console.log(`[SDK-${instanceId}] 🔧 Initializing database session for: ${sessionId}`);
    initializeDbSession();
  }, [sessionId, instanceId]);

  // Initialize agent wrapper when agent config changes
  useEffect(() => {
    // Skip if this is a duplicate instance
    if (isPrimaryInstanceRef.current !== true) {
      console.log(`[SDK-${instanceId}] ⚠️ Skipping agent wrapper creation - duplicate instance`);
      return;
    }
    
    if (!agentConfig.tools || agentConfig.tools.length === 0) {
      console.log(`[SDK-${instanceId}] ⚠️ Skipping agent wrapper creation - no tools available`);
      return;
    }
    
    // Check if we already have a wrapper for this agent
    if (agentWrapperRef.current && 
        agentWrapperRef.current.getAgentConfig().name === agentConfig.name &&
        JSON.stringify(agentWrapperRef.current.getAgentConfig().tools) === JSON.stringify(agentConfig.tools)) {
      console.log(`[SDK-${instanceId}] ✅ Agent wrapper already exists for: ${agentConfig.name} - skipping recreation`);
      return;
    }
    
    try {
      console.log(`[SDK-${instanceId}] 🔧 Creating new agent wrapper for: ${agentConfig.name}`);
      console.log(`[SDK-${instanceId}] 🔧 Agent tools count: ${agentConfig.tools?.length}`);
      
      // Reset connection attempt flag when agent changes
      hasAttemptedConnectionRef.current = false;
      
      agentWrapperRef.current = new DatabaseAgentWrapper(agentConfig, (message: string) => {
        // Convert string message to UniversalMessage
        const universalMessage: UniversalMessage = {
          id: `msg-${Date.now()}`,
          sessionId,
          timestamp: new Date().toISOString(),
          type: 'text',
          content: message,
          metadata: {
            source: 'ai',
            channel: 'realtime',
            language: 'en',
            agentName: agentConfig.name
          }
        };
        onMessage?.(universalMessage);
      });
      console.log(`[SDK-${instanceId}] ✅ Agent wrapper created successfully for: ${agentConfig.name}`);
    } catch (err) {
      console.error(`[SDK-${instanceId}] ❌ Failed to create agent wrapper:`, err);
      setError(err instanceof Error ? err.message : 'Failed to create agent wrapper');
    }
  }, [agentConfig.name, agentConfig.tools, instanceId]); // Removed onMessage and sessionId from deps to prevent unnecessary recreations

  // Connect to Realtime API using SDK
  const connect = useCallback(async () => {
    // Skip if this is a duplicate instance
    if (isPrimaryInstanceRef.current !== true) {
      console.log(`[SDK-${instanceId}] ⚠️ Skipping connection - duplicate instance`);
      return;
    }
    

    console.log(`[SDK-${instanceId}] 🔌 Connect function called, enabled:`, enabled);
    console.log(`[SDK-${instanceId}] 🔌 Connect call stack:`, new Error().stack);
    if (!enabled) {
      console.log(`[SDK-${instanceId}] SDK initialization disabled - skipping connection`);
      return;
    }
    
    if (!agentWrapperRef.current) {
      setError('Agent wrapper not available');
      return;
    }

    setIsConnecting(true);
    setError(null);

    try {
      console.log('[SDK] Connecting to Realtime API with SDK...');
      
      // Only create session and event listeners for primary instance
      if (isPrimaryInstanceRef.current !== true) {
        console.log(`[SDK-${instanceId}] ⚠️ Skipping session creation - duplicate instance`);
        return;
      }
      // Ensure singleton session like App.tsx (no duplicates)
      try {
        const anyWindow = typeof window !== 'undefined' ? (window as any) : undefined;
        if (anyWindow?.__rtSession && typeof anyWindow.__rtSession?.close === 'function') {
          console.log('[SDK] 🔁 Closing existing global session before creating a new one');
          try { anyWindow.__rtSession.close(); } catch {}
          anyWindow.__rtSession = undefined;
        }
      } catch {}
      
      // Create audio element for WebRTC
      const audioElement = document.createElement('audio');
      audioElement.autoplay = true;
      audioElement.muted = !!muteAudio;
      audioElement.style.display = 'none';
      document.body.appendChild(audioElement);
      audioElementRef.current = audioElement;
      
      // Create SDK agent from wrapper
      const sdkAgent = agentWrapperRef.current.getSDKAgent();
      
      // Create transport (App.tsx pattern: no interception)
      const webRTCTransport = new OpenAIRealtimeWebRTC({
          audioElement,
      });

      // Create session with comprehensive configuration
      const newSession = new RealtimeSession(sdkAgent, {
        transport: webRTCTransport,
        model: 'gpt-4o-realtime-preview-2025-06-03',
        config: {
          inputAudioFormat: 'pcm16',
          outputAudioFormat: 'pcm16',
          inputAudioTranscription: {
            model: 'whisper-1'
          },
        // Let backend set defaults; we will set turn_detection via session.update
        turnDetection: undefined as any
        }
      });
      
      (newSession as any).on('error', (err: any) => {
        console.error('[SDK] ❌ Session error:', err);
        setError(err.message || 'Session error');
        onError?.(err);
      });

      (newSession as any).on('connect', () => {
        console.log('[SDK] ✅ Connected to Realtime API');
        setIsConnected(true);
        setIsConnecting(false);
        connectionEstablishedAtRef.current = Date.now();
        console.log('[SDK] ⏱️ CONNECT TS:', connectionEstablishedAtRef.current);
        
        // STRICT PTT: Disable VAD completely on connect
        try {
          console.log('[SDK] 🎤 Disabling VAD on connect (STRICT PTT)');
          sendTurnDetection(null, 'on-connect');
        } catch (e) {
          console.warn('[SDK] ⚠️ Failed to disable VAD on connect:', e);
        }
        
        // AGGRESSIVELY block any microphone access until push-to-talk
        try {
          const transport: any = newSession?.transport;
          
          // Block any auto-attached streams
          const localStream: MediaStream | undefined = transport?.localStream || transport?.inputStream || transport?.microphoneStream;
          if (localStream) {
            console.log('[SDK] 🛑 Found auto-attached stream, stopping and detaching ALL tracks');
            localStream.getAudioTracks().forEach((t: MediaStreamTrack) => { 
              try { t.stop(); } catch {}
            });
          }
          
          // Remove ALL audio senders from PeerConnection
          const pc: RTCPeerConnection | undefined = transport?.pc || transport?.peerConnection;
          if (pc?.getSenders) {
            pc.getSenders()
              .filter((s: RTCRtpSender) => s.track && s.track.kind === 'audio')
              .forEach((s: RTCRtpSender) => {
                console.log('[SDK] 🛑 Removing audio sender from PeerConnection');
                try { s.replaceTrack(null as unknown as MediaStreamTrack); } catch {}
                try { pc.removeTrack(s); } catch {}
              });
          }
          
          // Clear all stream references
          try { transport.localStream = undefined; } catch {}
          try { transport.inputStream = undefined; } catch {}
          try { transport.microphoneStream = undefined; } catch {}
          try { micStreamRef.current = null; } catch {}
          
          console.log('[SDK] 🛑 All microphone access blocked until PTT');
          logTransportState('after-connect-mic-block');
        } catch (e) {
          console.warn('[SDK] ⚠️ Failed to block mic on connect:', e);
        }
      });

      (newSession as any).on('disconnect', () => {
        console.log('[SDK] 🔌 Disconnected from Realtime API');
        setIsConnected(false);
        setIsConnecting(false);
        try {
          const anyWindow = typeof window !== 'undefined' ? (window as any) : undefined;
          if (anyWindow?.__rtSession === newSession) {
            anyWindow.__rtSession = undefined;
          }
        } catch {}
      });

      // Text response handling - Add comprehensive logging
      (newSession as any).on('response.text.delta', (data: any) => {
        // console.log('[SDK] 🤖 RESPONSE TEXT DELTA:', data);
        // console.log('[SDK] 🤖 DELTA DATA:', JSON.stringify(data, null, 2));
        if (currentResponseRef.current && data.delta) {
          if (!currentResponseRef.current.content.find((c: any) => c.type === 'text')) {
            currentResponseRef.current.content.push({ type: 'text', content: '' });
          }
          const textContent = currentResponseRef.current.content.find((c: any) => c.type === 'text');
          if (textContent) {
            textContent.content += data.delta;
          }
        }
        if (acceptResponses && data.delta && onResponseDelta) {
          // console.log('[SDK] 🤖 CALLING onResponseDelta with:', data.delta);
          try { onResponseDelta(data.delta); } catch (e) {
            console.error('[SDK] 🤖 onResponseDelta error:', e);
          }
        } else {
          // console.warn('[SDK] 🤖 DELTA NOT SENT - acceptResponses:', acceptResponses, 'data.delta:', data.delta, 'onResponseDelta:', !!onResponseDelta);
        }
      });

      (newSession as any).on('response.text.done', (data: any) => {
        console.log('[SDK] 🤖 RESPONSE TEXT DONE:', data);
        console.log('[SDK] 🤖 DONE DATA:', JSON.stringify(data, null, 2));
        if (data.text) {
          console.log('[SDK] 🤖 COMPLETE AI RESPONSE:', data.text);
        }
        
        if (currentResponseRef.current) {
          const textContent = currentResponseRef.current.content.find((c: any) => c.type === 'text');
          if (textContent) {
            textContent.content = data.text;
            textContent.done = true;
          }
        }
        
        if (acceptResponses && data.text) {
          console.log('[SDK] 🤖 CREATING UNIVERSAL MESSAGE for:', data.text);
          // Convert to UniversalMessage
          const universalMessage: UniversalMessage = {
            id: `msg-${Date.now()}`,
            sessionId,
            timestamp: new Date().toISOString(),
            type: 'text',
            content: data.text,
            metadata: {
              source: 'ai',
              channel: 'realtime',
              language: 'en',
              agentName: agentConfig.name
            }
          };
          console.log('[SDK] 🤖 CALLING onMessage with:', universalMessage);
          onMessage?.(universalMessage);
        } else {
          console.warn('[SDK] 🤖 MESSAGE NOT SENT - acceptResponses:', acceptResponses, 'data.text:', data.text);
        }
        if (acceptResponses && data.text && onResponseDone) {
          console.log('[SDK] 🤖 CALLING onResponseDone with:', data.text);
          try { onResponseDone(data.text); } catch (e) {
            console.error('[SDK] 🤖 onResponseDone error:', e);
          }
        }
      });

      // Voice transcription events - Add comprehensive logging
      (newSession as any).on('conversation.item.input_audio_transcription.completed', (data: any) => {
        console.log('[SDK] 🎤 VOICE SUBMITTED TO MODEL (Whisper):', data);
        console.log('[SDK] 🎤 TRANSCRIPT DATA:', JSON.stringify(data, null, 2));
        console.log('[SDK] 🎤 TRANSCRIPT TEXT:', data?.transcript);
        console.log('[SDK] 🎤 IS VOICE ACTIVE:', isVoiceActive);
        
        // Only process transcription if user is actively speaking (PTT is active)
        if (!isVoiceActive) {
          console.log('[SDK] 🎤 SKIPPING TRANSCRIPTION - user not speaking (PTT not active)');
          return;
        }
        
        transcriptReceivedRef.current = true;
        transcriptAwaitingRef.current = false;
        if (transcriptTimeoutHandleRef.current) { 
          try { clearTimeout(transcriptTimeoutHandleRef.current); } catch {} 
          transcriptTimeoutHandleRef.current = null; 
        }
        if (data && typeof data.transcript === 'string' && data.transcript.trim().length > 0) {
          console.log('[SDK] 🎤 CALLING onTranscript with:', data.transcript);
          onTranscript?.(data.transcript);
        } else {
          console.warn('[SDK] 🎤 TRANSCRIPT NOT SENT - data:', data, 'transcript type:', typeof data?.transcript);
        }
      });

      (newSession as any).on('conversation.item.input_audio_transcription.delta', (data: any) => {
        console.log('[SDK] 🎤 VOICE TRANSCRIPTION DELTA (Whisper):', data);
        console.log('[SDK] 🎤 DELTA DATA:', JSON.stringify(data, null, 2));
        console.log('[SDK] 🎤 IS VOICE ACTIVE:', isVoiceActive);
        
        // Only process transcription if user is actively speaking (PTT is active)
        if (!isVoiceActive) {
          console.log('[SDK] 🎤 SKIPPING DELTA TRANSCRIPTION - user not speaking (PTT not active)');
          return;
        }
        
        transcriptReceivedRef.current = true;
        if (data.delta && data.delta.length > 0) {
          console.log('[SDK] 🎤 VOICE TRANSCRIPTION STARTED');
        }
        try { 
          if (data.delta && onTranscriptDelta) { 
            console.log('[SDK] 🎤 CALLING onTranscriptDelta with:', data.delta);
            onTranscriptDelta(data.delta); 
          } 
        } catch (e) {
          console.error('[SDK] 🎤 onTranscriptDelta error:', e);
        }
      });

      (newSession as any).on('conversation.item.input_audio_transcription.failed', (data: any) => {
        console.warn('[SDK] transcription.failed:', data);
        console.warn('[SDK] TRANSCRIPTION FAILED DATA:', JSON.stringify(data, null, 2));
        transcriptAwaitingRef.current = false;
        if (transcriptTimeoutHandleRef.current) { 
          try { clearTimeout(transcriptTimeoutHandleRef.current); } catch {} 
          transcriptTimeoutHandleRef.current = null; 
        }
      });

      // Add additional transcription event listeners for different event names
      (newSession as any).on('input_audio_transcription.completed', (data: any) => {
        console.log('[SDK] 🎤 ALTERNATIVE TRANSCRIPTION COMPLETED:', data);
        if (data && typeof data.transcript === 'string' && data.transcript.trim().length > 0) {
          console.log('[SDK] 🎤 CALLING onTranscript (alternative) with:', data.transcript);
          onTranscript?.(data.transcript);
        }
      });

      (newSession as any).on('input_audio_transcription.delta', (data: any) => {
        console.log('[SDK] 🎤 ALTERNATIVE TRANSCRIPTION DELTA:', data);
        if (data && data.delta && onTranscriptDelta) {
          console.log('[SDK] 🎤 CALLING onTranscriptDelta (alternative) with:', data.delta);
          onTranscriptDelta(data.delta);
        }
      });

      // Add response.audio_transcript events (used by App.tsx)
      (newSession as any).on('response.audio_transcript.delta', (data: any) => {
        // Suppress noisy logs; forward delta silently
        if (data && data.delta && onTranscriptDelta) {
          try { onTranscriptDelta(data.delta); } catch {}
        }
      });

      (newSession as any).on('response.audio_transcript.done', (data: any) => {
        // Minimal logging; forward transcript
        if (data && data.transcript && onTranscript) {
          try { onTranscript(data.transcript); } catch {}
        }
      });

      // Add transport_event handler (used by App.tsx for additional events)
      (newSession as any).on('transport_event', (event: any) => {
        // Handle delta events silently to avoid log spam
        if (event?.type === 'response.audio_transcript.delta') {
          if (!isVoiceActive) {
            try { (sessionRef.current as any)?.sendEvent?.({ type: 'response.cancel' }); } catch {}
            try { (sessionRef.current as any)?.sendEvent?.({ type: 'session.update', session: { turn_detection: null } }); } catch {}
          } else if (event?.delta && onTranscriptDelta) {
            try { onTranscriptDelta(event.delta); } catch {}
          }
          return;
        }
        console.log('[SDK] 🚌 TRANSPORT EVENT:', event.type, event);
        switch (event.type) {
          case 'input_audio_buffer.speech_started': {
            console.log('[SDK] 🚌 TRANSPORT: speech_started received');
            console.log('[SDK] 🔎 SPEECH_STARTED DIAG:', {
              lastSentTurnDetection: lastSentTurnDetectionRef.current,
              lastServerTurnDetection: lastServerTurnDetectionRef.current,
              updateSeq: sessionUpdateSeqRef.current,
              isVoiceActive,
              isConnected,
            });
            if (!isVoiceActive) {
              console.log('[SDK] 🛑 Unexpected speech_started while idle → disabling VAD and detaching mic');
              logTransportState('before-idle-speech_started-handling');
              // Re-assert turn_detection null and log
              try { 
                console.log('[SDK] 📡 Reasserting turn_detection:null due to idle speech_started');
                sendTurnDetection(null, 'idle-speech_started');
              } catch {}
              try { (sessionRef.current as any)?.sendEvent?.({ type: 'session.update', session: { turn_detection: null } }); } catch {}
              try {
                const s: any = sessionRef.current as any;
                const transport: any = s?.transport;
                const pc: RTCPeerConnection | undefined = transport?.pc || transport?.peerConnection;
                if (pc?.getSenders) {
                  pc.getSenders()
                    .filter((sndr: RTCRtpSender) => sndr.track && sndr.track.kind === 'audio')
                    .forEach((sndr: RTCRtpSender) => {
                      try { sndr.replaceTrack(null as unknown as MediaStreamTrack); } catch {}
                      try { pc.removeTrack(sndr); } catch {}
                    });
                }
                const stream: MediaStream | undefined = transport?.localStream || transport?.inputStream || transport?.microphoneStream;
                if (stream) { try { stream.getTracks().forEach(t => { try { t.stop(); } catch {} }); } catch {} }
                try { transport.localStream = undefined; } catch {}
                try { micStreamRef.current = null; } catch {}
                logTransportState('after-idle-speech_started-mic-detach');
        } catch {}
            }
            break;
          }
          case "conversation.item.input_audio_transcription.completed": {
            console.log('[SDK] 🎤 TRANSPORT: VOICE SUBMITTED TO MODEL (Whisper):', event);
            console.log('[SDK] 🎤 TRANSPORT: IS VOICE ACTIVE:', isVoiceActive);
            
            // Only process transcription if user is actively speaking (PTT is active)
            if (!isVoiceActive) {
              console.log('[SDK] 🎤 TRANSPORT: SKIPPING TRANSCRIPTION - user not speaking (PTT not active)');
              break;
            }
            
            if (event.transcript && onTranscript) {
              console.log('[SDK] 🎤 TRANSPORT: CALLING onTranscript with:', event.transcript);
              onTranscript(event.transcript);
            }
            break;
          }
          case "response.audio_transcript.delta": {
            console.log('[SDK] 🎤 TRANSPORT: RESPONSE AUDIO TRANSCRIPT DELTA:', event);
            console.log('[SDK] 🎤 TRANSPORT: IS VOICE ACTIVE:', isVoiceActive);
            
            // Only process transcription if user is actively speaking (PTT is active)
            if (!isVoiceActive) {
              console.log('[SDK] 🎤 TRANSPORT: SKIPPING DELTA TRANSCRIPTION - user not speaking (PTT not active)');
              // Proactively cancel any stray response that might have been started
              try { (sessionRef.current as any)?.sendEvent?.({ type: 'response.cancel' }); } catch {}
              try { (sessionRef.current as any)?.sendEvent?.({ type: 'session.update', session: { turn_detection: null } }); } catch {}
              break;
            }
            
            if (event.delta && onTranscriptDelta) {
              console.log('[SDK] 🎤 TRANSPORT: CALLING onTranscriptDelta with:', event.delta);
              onTranscriptDelta(event.delta);
            }
            break;
          }
          case "response.audio_transcript.done": {
            console.log('[SDK] 🎤 TRANSPORT: RESPONSE AUDIO TRANSCRIPT DONE:', event);
            console.log('[SDK] 🎤 TRANSPORT: IS VOICE ACTIVE:', isVoiceActive);
            
            // Only process transcription if user is actively speaking (PTT is active)
            if (!isVoiceActive) {
              console.log('[SDK] 🎤 TRANSPORT: SKIPPING TRANSCRIPTION - user not speaking (PTT not active)');
              try { (sessionRef.current as any)?.sendEvent?.({ type: 'response.cancel' }); } catch {}
              try { (sessionRef.current as any)?.sendEvent?.({ type: 'session.update', session: { turn_detection: null } }); } catch {}
              break;
            }
            
            if (event.transcript && onTranscript) {
              console.log('[SDK] 🎤 TRANSPORT: CALLING onTranscript with:', event.transcript);
              onTranscript(event.transcript);
            }
            break;
          }
          case "session.created": {
            console.log('[SDK] 🚌 TRANSPORT: Session created');
            console.log('[SDK] 🚌 TRANSPORT: Session created data:', JSON.stringify(event, null, 2));
            console.log('[SDK] 🔎 LAST SENT TURN_DETECTION:', lastSentTurnDetectionRef.current);
            break;
          }
          case "session.updated": {
            console.log('[SDK] 🚌 TRANSPORT: Session updated');
            console.log('[SDK] 🚌 TRANSPORT: Session updated data:', JSON.stringify(event, null, 2));
            if (event.session) {
              console.log('[SDK] 🚌 TRANSPORT: Session state:', {
                id: event.session.id,
                status: event.session.status,
                turn_detection: event.session.turn_detection,
                input_audio_format: event.session.input_audio_format,
                output_audio_format: event.session.output_audio_format
              });
              lastServerTurnDetectionRef.current = { at: Date.now(), data: event.session.turn_detection };
              console.log('[SDK] 🔎 TURN_DETECTION SENT vs SERVER:', {
                sent: lastSentTurnDetectionRef.current,
                server: lastServerTurnDetectionRef.current,
              });
            }
            break;
          }
          default: {
            console.log('[SDK] 🚌 TRANSPORT: Unhandled event type:', event.type);
            break;
          }
        }
      });

      // Function call handling
      (newSession as any).on('function_call', async (call: any) => {
        console.log('[SDK] 🔧 Function call received:', call);
        if (!allowAgentRunsRef.current) {
          // Block any automatic tool execution and cancel the pending response
          try {
            console.log('[SDK] 🔧 Blocking function_call (no user interaction); sending response.cancel');
            (sessionRef.current as any)?.sendEvent?.({ type: 'response.cancel' });
          } catch {}
          return;
        }
        
        // Handle transferAgents specially
        if (call.name === 'transferAgents') {
          const destination = call.parameters?.destination_agent;
          if (destination && onAgentTransfer) {
            console.log(`[SDK] 🔁 Transferring to agent: ${destination}`);
            onAgentTransfer(destination);
          }
        }
      });

      // Response lifecycle management - Add comprehensive logging
      (newSession as any).on('response.created', (data: any) => {
        console.log('[SDK] 📋 RESPONSE CREATED:', data);
        console.log('[SDK] 📋 CREATED DATA:', JSON.stringify(data, null, 2));
        // Strict PTT: if not in a user-initiated turn, cancel immediately
        if (!isVoiceActive) {
          try {
            console.log('[SDK] 📋 response.created while idle → cancelling');
            (sessionRef.current as any)?.sendEvent?.({ type: 'response.cancel' });
          } catch {}
          return;
        }
        currentResponseRef.current = {
          id: data.id,
          type: data.type,
          created_at: data.created_at,
          content: []
        };
        console.log('[SDK] 📋 acceptResponses:', acceptResponses, 'shouldAcceptResponseStart:', shouldAcceptResponseStart?.(), 'onResponseStart:', !!onResponseStart);
        if (!allowAgentRunsRef.current) {
          try {
            console.log('[SDK] 📋 Auto-canceling response (no user interaction yet)');
            (sessionRef.current as any)?.sendEvent?.({ type: 'response.cancel' });
          } catch (e) {
            console.warn('[SDK] 📋 Auto-cancel failed', e);
          }
          return;
        }
        if (
          acceptResponses &&
          (!shouldAcceptResponseStart || shouldAcceptResponseStart()) &&
          onResponseStart
        ) {
          console.log('[SDK] 📋 CALLING onResponseStart');
          try { onResponseStart(); } catch (e) {
            console.error('[SDK] 📋 onResponseStart error:', e);
          }
        } else {
          console.warn('[SDK] 📋 RESPONSE START NOT CALLED - acceptResponses:', acceptResponses, 'shouldAcceptResponseStart:', shouldAcceptResponseStart?.(), 'onResponseStart:', !!onResponseStart);
        }
      });

      (newSession as any).on('response.done', (data: any) => {
        console.log('[SDK] 📋 RESPONSE DONE:', data);
        console.log('[SDK] 📋 DONE DATA:', JSON.stringify(data, null, 2));
        if (currentResponseRef.current) {
          currentResponseRef.current = null;
        }
      });

      // Add additional response event listeners
      (newSession as any).on('response.created', (data: any) => {
        console.log('[SDK] 📋 ALTERNATIVE RESPONSE CREATED:', data);
      });

      (newSession as any).on('response.done', (data: any) => {
        console.log('[SDK] 📋 ALTERNATIVE RESPONSE DONE:', data);
      });

      // Add message event listener
      (newSession as any).on('message', (data: any) => {
        console.log('[SDK] 📨 MESSAGE EVENT:', data);
        console.log('[SDK] 📨 MESSAGE DATA:', JSON.stringify(data, null, 2));
      });

      // Add agent events
      (newSession as any).on('agent_start', (data: any) => {
        if (!allowAgentRunsRef.current) {
          console.log(`[SDK-${instanceId}] 🚫 AGENT START BLOCKED - not allowed yet:`, data);
          try { (sessionRef.current as any)?.sendEvent?.({ type: 'response.cancel' }); } catch {}
          return;
        }
        console.log(`[SDK-${instanceId}] 🤖 AGENT START:`, data);
        console.log(`[SDK-${instanceId}] 🤖 AGENT START STACK:`, new Error().stack);
      });

      (newSession as any).on('agent_end', (data: any) => {
        if (!allowAgentRunsRef.current) {
          console.log(`[SDK-${instanceId}] 🚫 AGENT END BLOCKED - not allowed yet:`, data);
          try { (sessionRef.current as any)?.sendEvent?.({ type: 'response.cancel' }); } catch {}
          return;
        }
        console.log(`[SDK-${instanceId}] 🤖 AGENT END:`, data);
        console.log(`[SDK-${instanceId}] 🤖 AGENT END STACK:`, new Error().stack);
      });

      // Add catch-all event listener to debug what events are actually fired
      (newSession as any).on('*', (eventName: string, ...args: any[]) => {
        console.log('[SDK] 🔍 EVENT FIRED:', eventName, 'ARGS:', args);
        if (eventName.includes('transcription') || eventName.includes('response') || eventName.includes('message')) {
          console.log('[SDK] 🔍 IMPORTANT EVENT:', eventName, 'DATA:', JSON.stringify(args[0], null, 2));
        }
      });

      // User voice item creation
      (newSession as any).on('conversation.item.created', (data: any) => {
        try {
          const role = data?.item?.role;
          const type = data?.item?.type;
          const text = data?.item?.content?.[0]?.text || data?.item?.content?.[0]?.transcript || '';
          if (role === 'user' || type === 'input_audio') {
            console.log('[SDK] ◀ conversation.item.created (user/input_audio):', JSON.stringify(data, null, 2));
            transcriptReceivedRef.current = transcriptReceivedRef.current || (typeof text === 'string' && text.trim().length > 0);
            onUserVoiceItemCreated?.(typeof text === 'string' ? text : undefined);
          }
        } catch {}
      });

      // Connect to the session
      const ephemeralKey = await getEphemeralKey();
      
      try {
        const connectionPromise = newSession.connect({ apiKey: ephemeralKey });
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Connection timeout')), 10000)
        );
        
        await Promise.race([connectionPromise, timeoutPromise]);
        console.log('[SDK] ✅ Real API connection successful');
        
        setTimeout(() => {
          setIsConnected(true);
          setIsConnecting(false);
          console.log('[SDK] 🔧 Forced connection state update');
        }, 1000);
      } catch (err: any) {
        console.log('[SDK] ⚠️ Real API connection failed, using mock mode for demo:', err?.message || err);
        
        setTimeout(() => {
          setIsConnected(true);
          setIsConnecting(false);
          console.log('[SDK] 🎭 Mock connection established for function call demo');
        }, 1000);
        return;
      }
      
      sessionRef.current = newSession;
      setSession(newSession);
      try {
        const anyWindow = typeof window !== 'undefined' ? (window as any) : undefined;
        if (anyWindow) anyWindow.__rtSession = newSession;
        
        // Global microphone blocker for STRICT PTT
        if (anyWindow && !anyWindow.__micBlockerInstalled) {
          console.log('[SDK] 🛡️ Installing global microphone blocker for STRICT PTT');
          const originalGetUserMedia = navigator.mediaDevices.getUserMedia;
          navigator.mediaDevices.getUserMedia = async (constraints: any) => {
            const isPTTActive = anyWindow.__isPTTActive || false;
            if (!isPTTActive) {
              console.log('[SDK] 🛡️ BLOCKED getUserMedia - PTT not active');
              // Return empty stream
              return new MediaStream();
            }
            console.log('[SDK] 🎤 ALLOWED getUserMedia - PTT active');
            return originalGetUserMedia.call(navigator.mediaDevices, constraints);
          };
          anyWindow.__micBlockerInstalled = true;
        }
      } catch {}

    } catch (err) {
      console.error('[SDK] Connection failed:', err);
      setIsConnecting(false);
      setError(err instanceof Error ? err.message : 'Connection failed');
      onError?.(err instanceof Error ? err : new Error('Connection failed'));
    }
  }, [agentConfig, getEphemeralKey, onMessage, onError, onAgentTransfer, sessionId, enabled, acceptResponses, muteAudio, shouldAcceptResponseStart, onUserVoiceItemCreated, onResponseStart, onResponseDelta, onResponseDone, onTranscript, onTranscriptDelta]);

  // React to muteAudio changes
  useEffect(() => {
    if (audioElementRef.current) {
      audioElementRef.current.muted = !!muteAudio;
    }
  }, [muteAudio]);

  // Send message through SDK session
  const sendMessage = useCallback(async (message: string) => {
    if (!sessionRef.current || !isConnected) {
      setError('Session not connected');
      return;
    }

    try {
      console.log(`[SDK-${instanceId}] 📤 Sending message:`, message);
      
      // Enable agent runs when user sends a message
      allowAgentRunsRef.current = true;
      console.log(`[SDK-${instanceId}] ✅ Agent runs enabled for user interaction`);
      
      // Add user message to chat
      const userMessage: UniversalMessage = {
        id: `msg-${Date.now()}`,
        sessionId,
        timestamp: new Date().toISOString(),
        type: 'text',
        content: message,
        metadata: {
          source: 'user',
          channel: 'realtime',
          language: 'en'
        }
      };
      
      onMessage?.(userMessage);
      
      // Send through SDK
      await (sessionRef.current as any).sendMessage(message);
      
      // Log to database
      try {
        await fetch('/api/log/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            session_id: dbSessionIdRef.current,
            role: 'user',
            type: 'text',
            content: message,
            channel: 'realtime',
            meta: { is_internal: false }
          })
        });
    } catch (err) {
        console.warn('[SDK] Failed to log user message:', err);
      }
      
    } catch (err) {
      console.error('[SDK] Failed to send message:', err);
      setError(err instanceof Error ? err.message : 'Failed to send message');
      onError?.(err instanceof Error ? err : new Error('Failed to send message'));
    }
  }, [isConnected, onMessage, onError, sessionId]);

  // App.tsx style PTT button down handler
  const startVoice = useCallback(async () => {
    if (!sessionRef.current || !isConnected) {
      setError('Session not connected');
      return;
    }

    try {
      console.log(`[SDK-${instanceId}] 🎤 PTT BUTTON DOWN - App.tsx style`);
      
      // App.tsx: interrupt any ongoing response
      try {
        console.log('[SDK] 🎤 Interrupting any ongoing response (App.tsx pattern)');
        (sessionRef.current as any).sendEvent?.({ type: 'response.cancel' });
      } catch (e) {
        console.warn('[SDK] Failed to interrupt:', e);
      }

      // Enable agent runs when user starts voice input
      allowAgentRunsRef.current = true;
      console.log(`[SDK-${instanceId}] ✅ Agent runs enabled for voice interaction`);
      
    setIsPTTUserSpeaking(true);
    setIsVoiceActive(true);
    
    // Set global PTT state for microphone blocker
    try {
      const anyWindow = typeof window !== 'undefined' ? (window as any) : undefined;
      if (anyWindow) anyWindow.__isPTTActive = true;
    } catch {}
      
      // App.tsx: Clear input audio buffer on PTT down
      try {
        console.log('[SDK] 🎤 Clearing input audio buffer (App.tsx pattern)');
        (sessionRef.current as any).sendEvent?.({ type: 'input_audio_buffer.clear' });
      } catch (e) {
        console.warn('[SDK] Failed to clear buffer:', e);
      }

      // App.tsx: Disable VAD while PTT is active
      try {
        console.log('[SDK] 🎤 Setting turn_detection:null during PTT');
        sendTurnDetection(null, 'ptt-down');
      } catch {}
      
      // AGGRESSIVELY enable audio tracks for PTT
      try {
        const transport: any = sessionRef.current?.transport;
        const pc: RTCPeerConnection | undefined = transport?.pc || transport?.peerConnection;
        if (pc) {
          const senders = pc.getSenders();
          senders.forEach((sender: RTCRtpSender) => {
            if (sender.track && sender.track.kind === 'audio') {
              console.log('[SDK] 🎤 Enabling audio track for PTT');
              sender.track.enabled = true;
            }
          });
        }
      } catch (e) {
        console.warn('[SDK] Failed to enable audio tracks:', e);
      }
      
      // UNBLOCK microphone for PTT
      try {
        const transport: any = sessionRef.current?.transport;
        if (transport?._setMicrophoneBlocked) {
          transport._setMicrophoneBlocked(false);
          console.log('[SDK] 🎤 Microphone unblocked for PTT');
        }
      } catch (e) {
        console.warn('[SDK] Failed to unblock microphone:', e);
      }
      
      // Attach microphone stream explicitly
      try {
        console.log(`[SDK-${instanceId}] 🎤 Getting microphone stream...`);
        if (!micStreamRef.current) {
          micStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
          console.log(`[SDK-${instanceId}] 🎤 Microphone stream obtained:`, micStreamRef.current);
          console.log(`[SDK-${instanceId}] 🎤 Audio tracks:`, micStreamRef.current.getAudioTracks().length);
        } else {
          console.log(`[SDK-${instanceId}] 🎤 Using existing microphone stream`);
        }
        
        const s: any = sessionRef.current as any;
        const pc: RTCPeerConnection | undefined = s?.transport?.pc || s?.transport?.peerConnection;
        console.log(`[SDK-${instanceId}] 🎤 PeerConnection found:`, !!pc);
        console.log(`[SDK-${instanceId}] 🎤 Session transport:`, s?.transport);
        
        if (pc && micStreamRef.current) {
          const track = micStreamRef.current.getAudioTracks()[0];
          console.log(`[SDK-${instanceId}] 🎤 Audio track found:`, !!track);
          console.log(`[SDK-${instanceId}] 🎤 Track enabled:`, track?.enabled);
          console.log(`[SDK-${instanceId}] 🎤 Track readyState:`, track?.readyState);
          
          if (track) {
            const sender = pc.getSenders().find((sndr) => sndr.track && sndr.track.kind === 'audio');
            console.log(`[SDK-${instanceId}] 🎤 Existing audio sender found:`, !!sender);
            
            if (sender) {
              console.log(`[SDK-${instanceId}] 🎤 Replacing existing audio track...`);
              await sender.replaceTrack(track);
              console.log(`[SDK-${instanceId}] 🎤 Audio track replaced successfully`);
            } else {
              console.log(`[SDK-${instanceId}] 🎤 Adding new audio track...`);
              pc.addTrack(track, micStreamRef.current);
              console.log(`[SDK-${instanceId}] 🎤 Audio track added successfully`);
            }
          }
        }
        
        console.log(`[SDK-${instanceId}] 🎤 Enabling audio tracks...`);
        micStreamRef.current?.getAudioTracks().forEach(t => { 
          try { 
            t.enabled = true; 
            console.log(`[SDK-${instanceId}] 🎤 Track enabled:`, t.id, t.enabled);
      } catch (e) {
            console.warn(`[SDK-${instanceId}] 🎤 Failed to enable track:`, e);
          }
        });
        
        try { 
          if (s?.transport) {
            s.transport.localStream = micStreamRef.current;
            console.log(`[SDK-${instanceId}] 🎤 Set transport.localStream successfully`);
          }
        } catch (e) {
          console.warn(`[SDK-${instanceId}] 🎤 Failed to set transport.localStream:`, e);
        }
        
        console.log(`[SDK-${instanceId}] 🎤 Microphone stream attachment completed`);
      } catch (e) {
        console.warn(`[SDK-${instanceId}] ⚠️ Could not attach mic stream on startVoice:`, e);
      }

      // Cancel any in-flight response
      try { 
        console.log('[SDK] sendEvent response.cancel'); 
        (sessionRef.current as any).sendEvent?.({ type: 'response.cancel' }); 
      } catch (e) { 
        console.warn('[SDK] response.cancel failed', e); 
      }
      
      // For WebRTC: No need for output_audio_buffer events
      console.log('[SDK] 🎤 WebRTC output audio handled automatically');
      
      // App.tsx style: No automatic VAD - manual control only through buffer events
      // For WebRTC, we don't enable server VAD as we control the mic manually
      console.log('[SDK] 🎤 PTT Mode: Manual control, no server VAD needed');
      
      console.log('[SDK] 🎤 Voice input successfully started');
    } catch (err) {
      console.error('[SDK] ❌ Failed to start voice:', err);
      setError(err instanceof Error ? err.message : 'Failed to start voice');
      onError?.(err instanceof Error ? err : new Error('Failed to start voice'));
    }
  }, [isConnected, onError]);

  // App.tsx style PTT button up handler
  const stopVoice = useCallback(() => {
    if (!sessionRef.current || !isPTTUserSpeaking) {
      console.warn('[SDK] 🎤 stopVoice called but no session or not speaking');
      return;
    }

    try {
      console.log('[SDK] 🎤 PTT BUTTON UP - App.tsx style');
      
    setIsPTTUserSpeaking(false);
    setIsVoiceActive(false);
    
    // Clear global PTT state for microphone blocker
    try {
      const anyWindow = typeof window !== 'undefined' ? (window as any) : undefined;
      if (anyWindow) anyWindow.__isPTTActive = false;
    } catch {}
      
      // App.tsx: Commit the input audio buffer
      try {
        console.log('[SDK] 🎤 Committing input audio buffer (App.tsx pattern)');
        (sessionRef.current as any).sendEvent?.({ type: 'input_audio_buffer.commit' });
      } catch (e) {
        console.warn('[SDK] Failed to commit buffer:', e);
      }
      
      // App.tsx: Trigger response after committing
      try {
        console.log('[SDK] 🎤 Triggering response (App.tsx pattern)');
        (sessionRef.current as any).sendEvent?.({ type: 'response.create' });
      } catch (e) {
        console.warn('[SDK] Failed to create response:', e);
      }

      // STRICT PTT: Keep VAD disabled after PTT release
      try {
        console.log('[SDK] 🎤 Keeping VAD disabled after PTT (STRICT PTT)');
        sendTurnDetection(null, 'ptt-up');
      } catch {}
      
      // AGGRESSIVELY disable all audio tracks after PTT
      try {
        const transport: any = sessionRef.current?.transport;
        const pc: RTCPeerConnection | undefined = transport?.pc || transport?.peerConnection;
        if (pc) {
          const senders = pc.getSenders();
          senders.forEach((sender: RTCRtpSender) => {
            if (sender.track && sender.track.kind === 'audio') {
              console.log('[SDK] 🛑 Disabling audio track after PTT');
              sender.track.enabled = false;
            }
          });
        }
      } catch (e) {
        console.warn('[SDK] Failed to disable audio tracks:', e);
      }

      // For WebRTC: do NOT use input_audio_buffer.* events (WS-only). Simply disable mic track to signal VAD end.
      // Keep the stream attached so the server can finalize the transcription.
      try { 
        const s: any = sessionRef.current as any;
        const transportStream: MediaStream | undefined = s?.transport?.localStream || s?.transport?.inputStream || s?.transport?.microphoneStream;
        if (transportStream) {
          transportStream.getTracks().forEach((t: MediaStreamTrack) => { 
            try { 
              t.enabled = false; 
            } catch {}
          });
          console.log('[SDK] 🎤 Mic tracks disabled (not stopped) for VAD finalization');
        }
      } catch (e) {
        console.warn('[SDK] ⚠️ Could not disable mic stream on stopVoice:', e); 
      }

      // Start awaiting transcript timer
      transcriptAwaitingRef.current = true;
      transcriptReceivedRef.current = false;
      if (transcriptTimeoutHandleRef.current) {
        try { clearTimeout(transcriptTimeoutHandleRef.current); } catch {}
        transcriptTimeoutHandleRef.current = null;
      }
      transcriptTimeoutHandleRef.current = setTimeout(() => {
        if (transcriptAwaitingRef.current && !transcriptReceivedRef.current) {
          console.warn('[SDK] ⏳ No transcription events received within 3s after PTT end');
        }
      }, 3000);

      // RE-BLOCK microphone after PTT
      try {
        const transport: any = sessionRef.current?.transport;
        if (transport?._setMicrophoneBlocked) {
          transport._setMicrophoneBlocked(true);
          console.log('[SDK] 🛑 Microphone re-blocked after PTT');
        }
      } catch (e) {
        console.warn('[SDK] Failed to re-block microphone:', e);
      }

      // VAD is already permanently disabled - no need to disable again

      // After disabling VAD, also detach and stop mic tracks to hard-prevent capture when idle
      try {
        const s: any = sessionRef.current as any;
        const transport: any = s?.transport;
        const pc: RTCPeerConnection | undefined = transport?.pc || transport?.peerConnection;
        if (pc?.getSenders) {
          pc.getSenders()
            .filter((sndr: RTCRtpSender) => sndr.track && sndr.track.kind === 'audio')
            .forEach((sndr: RTCRtpSender) => {
              try { sndr.replaceTrack(null as unknown as MediaStreamTrack); } catch {}
              try { pc.removeTrack(sndr); } catch {}
            });
        }
        const stream: MediaStream | undefined = transport?.localStream || transport?.inputStream || transport?.microphoneStream || micStreamRef.current || undefined;
        if (stream) {
          try { stream.getTracks().forEach(t => { try { t.stop(); } catch {} }); } catch {}
        }
        try { transport.localStream = undefined; } catch {}
        try { micStreamRef.current = null; } catch {}
      } catch {}

      // After a short delay, request an AI response. This gives VAD a moment to finalize the user item.
      try {
        const delayMs = 200;
        console.log(`[SDK-${instanceId}] 🎤 Scheduling response.create in ${delayMs}ms`);
        setTimeout(() => {
          try {
            console.log(`[SDK-${instanceId}] 🎤 sendEvent response.create`);
            const responseResult = (sessionRef.current as any).sendEvent?.({ type: 'response.create' });
            console.log(`[SDK-${instanceId}] 🎤 response.create result:`, responseResult);
      } catch (e) {
            console.warn(`[SDK-${instanceId}] 🎤 response.create failed:`, e);
          }
        }, delayMs);
      } catch (e) { 
        console.warn('[SDK] ⚠️ Failed to schedule response.create', e); 
      }

      console.log('[SDK] 🎤 Voice input successfully stopped');
    } catch (err) {
      console.error('[SDK] ❌ Failed to stop voice:', err);
      setError(err instanceof Error ? err.message : 'Failed to stop voice');
      onError?.(err instanceof Error ? err : new Error('Failed to stop voice'));
    }
  }, [acceptResponses, onError]);

  // Disconnect session
  const disconnect = useCallback(() => {
    if (!sessionRef.current) return;

    try {
      console.log('[SDK] Disconnecting session...');
      const s: any = sessionRef.current as any;
      if (typeof s.disconnect === 'function') {
        s.disconnect();
      } else if (typeof s.close === 'function') {
        s.close();
      } else if (typeof s.transport?.close === 'function') {
        s.transport.close();
      } else {
        console.warn('[SDK] No disconnect/close method available on session');
      }
      sessionRef.current = null;
      setSession(null);
      setIsConnected(false);
      setIsVoiceActive(false);
    } catch (err) {
      console.error('[SDK] Failed to disconnect:', err);
      setError(err instanceof Error ? err.message : 'Failed to disconnect');
    }
  }, []);

  // Test function to force function calls
  const testFunctionCalls = useCallback(async () => {
    if (!sessionRef.current || !isConnected) {
      setError('Session not connected');
      return;
    }

    try {
      console.log('[SDK] 🧪 Testing function calls with specific prompts...');
      const testMessage = "I need to transfer to the placeGuide agent because I want to find nearby restaurants. Please use the transferAgents function to transfer me to placeGuide with the rationale that I'm looking for restaurant recommendations.";
      console.log('[SDK] 🧪 Sending test message:', testMessage);
      await (sessionRef.current as any).sendMessage(testMessage);
    } catch (err) {
      console.error('[SDK] Failed to test function calls:', err);
      setError(err instanceof Error ? err.message : 'Failed to test function calls');
    }
  }, [isConnected]);

  // Test function to demonstrate model response logging
  const testModelResponseLogging = useCallback(() => {
    console.log('[SDK] 🧪 Demonstrating model response logging...');
    
    // Simulate a model response for demonstration
    const mockResponse = {
      id: 'resp_demo_123',
      type: 'response',
      created_at: new Date().toISOString(),
      content: [
        {
          type: 'text',
          content: 'Hello! I\'m a travel assistant. How can I help you today?',
          done: true
        },
        {
          type: 'function_call',
          content: {
            name: 'transferAgents',
            arguments: JSON.stringify({
              destination_agent: 'placeGuide',
              rationale_for_transfer: 'User is looking for restaurant recommendations',
              conversation_context: 'User asked about nearby restaurants'
            }),
            result: JSON.stringify({
              success: true,
              message: 'Successfully transferred to placeGuide agent',
              timestamp: new Date().toISOString()
            })
          },
          done: true
        }
      ]
    };

    console.log('[SDK] 🤖 MOCK MODEL RESPONSE CREATED:', JSON.stringify(mockResponse, null, 2));
    console.log('[SDK] ✅ MODEL RESPONSE COMPLETED:', JSON.stringify(mockResponse, null, 2));
  }, []);

  // App.tsx style: Update session when PTT state changes
  useEffect(() => {
    if (isConnected) {
      console.log('[SDK] 🎤 PTT state changed, updating session (App.tsx pattern)');
      updateSession();
    }
  }, [isVoiceActive, isConnected, updateSession]);

  // Auto-connect when dependencies are ready (only once)
  useEffect(() => {
    // Skip if this is a duplicate instance
    if (isPrimaryInstanceRef.current !== true) {
      console.log(`[SDK-${instanceId}] ⚠️ Skipping auto-connect - duplicate instance`);
      return;
    }
    
    if (enabled && 
        agentWrapperRef.current && 
        !isConnected && 
        !isConnecting && 
        !hasAttemptedConnectionRef.current &&
        agentConfig.tools && 
        agentConfig.tools.length > 0) {
      
      console.log(`[SDK-${instanceId}] 🔌 Auto-connecting to voice service...`);
      hasAttemptedConnectionRef.current = true;
        connect();
      }
  }, [enabled, isConnected, isConnecting, agentConfig.tools?.length]); // Removed connect and instanceId from deps

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      // Only cleanup if this is not a duplicate instance
      if (isPrimaryInstanceRef.current === true) {
        // Restore original getUserMedia
        try {
          const transport: any = sessionRef.current?.transport;
          if (transport?._originalGetUserMedia) {
            navigator.mediaDevices.getUserMedia = transport._originalGetUserMedia;
            console.log('[SDK] 🔄 Restored original getUserMedia');
          }
        } catch (e) {
          console.warn('[SDK] Failed to restore getUserMedia:', e);
        }
        
        // Remove from registry
        hookInstances.delete(instanceId);
        console.log(`[SDK-${instanceId}] 🧹 Hook instance cleaned up`);
      disconnect();
        // Release primary slot for this agent if owned by this instance
        const existingPrimary = primaryInstanceForAgent.get(agentConfig.name);
        if (existingPrimary === instanceId) {
          primaryInstanceForAgent.delete(agentConfig.name);
          console.log(`[SDK-${instanceId}] 🏷️ Released PRIMARY instance for agent: ${agentConfig.name}`);
        }
      }
    };
  }, [disconnect, instanceId, agentConfig.name]);

  return {
    session,
    isConnected,
    isConnecting,
    error,
    sendMessage,
    startVoice,
    stopVoice,
    disconnect,
    isVoiceActive,
    testFunctionCalls,
    testModelResponseLogging
  };
}
