## Agent Structure Standard / มาตรฐานโครงสร้างเอเจนต์

This document defines the standard folder layout, required files, naming, and integration rules for creating agents in this project.

เอกสารนี้กำหนดมาตรฐานโครงสร้างโฟลเดอร์ ไฟล์ที่จำเป็น การตั้งชื่อ และกติกาการเชื่อมต่อสำหรับการสร้างเอเจนต์ในโปรเจกต์นี้

---

## Goals / เป้าหมาย

- Establish a consistent, discoverable structure for all agents
- Standardize how core tools and handlers are used
- Make agent registration and transfer predictable

- สร้างโครงสร้างที่เป็นมาตรฐานและค้นหาได้ง่ายสำหรับทุกเอเจนต์
- ทำให้การใช้งาน core tools และ handlers เป็นมาตรฐานเดียวกัน
- ทำให้การลงทะเบียนและการโอนถ่าย (transfer) ระหว่างเอเจนต์สอดคล้องกัน

---

## Directory Layout / โครงสร้างไดเรกทอรี

Place each agent under `src/app/agents/<agentName>/` with this structure.

ให้วางแต่ละเอเจนต์ภายใต้ `src/app/agents/<agentName>/` ด้วยโครงสร้างด้านล่าง

```
src/app/agents/<agentName>/
├── index.ts                  # Export AgentConfig[] and inject transfer tools
├── README.md                 # Agent-specific docs (optional)
├── config/
│   ├── agentConfig.ts        # Main AgentConfig (required)
│   └── functions.ts          # Additional function schemas (optional)
├── functions/
│   └── handlers/             # Custom tool logic handlers (optional)
├── data/                     # Agent data (optional)
├── services/                 # Service layer (optional)
├── hooks/                    # React hooks (optional)
└── types/                    # Local types (optional)
```

Notes / หมายเหตุ:
- Keep agent-specific schemas minimal; prefer core schemas/handlers from `agents/core/functions`.
- ใช้สChemas/handlers กลางจาก `agents/core/functions` เป็นหลัก ลดสChemasเฉพาะ agent เท่าที่จำเป็น

---

## Agent Contract / สัญญา Agent (AgentConfig)

Every agent must export an `AgentConfig` object in `config/agentConfig.ts`.

ทุกเอเจนต์ต้อง export อ็อบเจ็กต์ `AgentConfig` ภายใน `config/agentConfig.ts`

Required fields / ฟิลด์ที่จำเป็น:
- `name: string` — unique agent name
- `publicDescription: string` — short UI-facing description
- `instructions: string` — system prompt/instructions for the agent
- `tools: Tool[]` — JSON schema function definitions (usually from core)
- `toolLogic: Record<string, (args:any)=>Promise<any>>` — function handlers
- `transferSettings: { autoGenerateFirstMessage?: boolean; waitForVoicePlayback?: boolean; initialPrompt?: string; initialSystemPrompt?: string }`

Optional / ตัวเลือก:
- `downstreamAgents?: { name: string; publicDescription?: string }[]` — for dispatcher agents to enable dynamic `transferAgents` enum injection

---

## Core Reuse / การใช้ Core ร่วม

Use the core schemas and handlers via `CoreFunctionConfig` to avoid duplication.

ใช้ core schemas และ handlers ผ่าน `CoreFunctionConfig` เพื่อลดความซ้ำซ้อน

```ts
// config/agentConfig.ts (example)
import { AgentConfig } from "@/app/types";
import { 
  getCoreSchemasByConfig, 
  getCoreHandlersByConfig, 
  createTransferBackHandler,
  type CoreFunctionConfig
} from "../../core/functions";

const CORE_CONFIG: CoreFunctionConfig = {
  core: true,  // intentionChange, transferAgents, transferBack
  ui: true,    // navigateToMain, navigateToPrevious
  skill: true, // knowledgeSearch, webSearch
};

const coreSchemas = getCoreSchemasByConfig(CORE_CONFIG);
const coreHandlers = getCoreHandlersByConfig(CORE_CONFIG);

const myAgent: AgentConfig = {
  name: "myAgent",
  publicDescription: "My sample agent",
  instructions: `
    Respond in the user's language. Keep replies concise and helpful.
  `,
  tools: coreSchemas,
  toolLogic: {
    ...coreHandlers,
    transferBack: createTransferBackHandler("myAgent"),
    // Add/override handlers here if needed
  },
  transferSettings: {
    autoGenerateFirstMessage: false,
    waitForVoicePlayback: false,
  },
};

export default myAgent;
```

TH: ใช้ core schemas/handlers ด้วย `getCoreSchemasByConfig` และ `getCoreHandlersByConfig` และเพิ่ม `transferBack` ผ่าน `createTransferBackHandler(<agentName>)`

---

## Export Pattern / รูปแบบการ Export (index.ts)

Each agent folder must export an array of `AgentConfig` via `index.ts`. Use dynamic injection utilities to add transfer tool schemas where appropriate.

ทุกโฟลเดอร์เอเจนต์ต้อง export อาเรย์ของ `AgentConfig` ผ่าน `index.ts` และใช้ util สำหรับ dynamic injection เพื่อเพิ่ม transfer tools เมื่อจำเป็น

```ts
// index.ts
import { injectTransferTools, injectTransferBackTools } from "../core/functions";
import { AgentConfig } from "@/app/types";
import myAgent from "./config/agentConfig";

const agent: AgentConfig = myAgent;

let agents = injectTransferTools([agent]);
agents = injectTransferBackTools(agents, "default");

export default agents; // AgentConfig[]
```

TH: ให้ export เป็นอาเรย์ `AgentConfig[]` และใช้ `injectTransferTools`/`injectTransferBackTools` เสมอเพื่อความสอดคล้อง

---

## Registration / การลงทะเบียนเอเจนต์

Register your agent in `src/app/agents/index.ts` by importing the folder default export and adding to `allAgentSets`.

ให้ลงทะเบียนเอเจนต์ใน `src/app/agents/index.ts` โดย import default export ของโฟลเดอร์และเพิ่มลงใน `allAgentSets`

```ts
// src/app/agents/index.ts
import myAgent from "./myAgent";

export const allAgentSets = {
  // ...existing
  myAgent,
};
```

Ensure the key matches your `AgentConfig.name` when used in routing/transfer.

TH: ตรวจให้แน่ใจว่า key ตรงกับ `AgentConfig.name` เมื่อใช้กับการ route/transfer

---

## Transfers / การโอนถ่ายระหว่างเอเจนต์

- `transferAgents`: Provided by core. For dispatcher agents, define `downstreamAgents` to enable enum-restricted destinations via dynamic injection.
- `transferBack`: Add via `createTransferBackHandler(<agentName>)` and injected via `injectTransferBackTools`.

- `transferAgents`: มีใน core สำหรับเอเจนต์ที่ทำหน้าที่กระจาย ให้ระบุ `downstreamAgents` เพื่อสร้าง enum ของปลายทางอัตโนมัติ
- `transferBack`: เพิ่มผ่าน `createTransferBackHandler(<agentName>)` และใช้ `injectTransferBackTools`

Downstream example / ตัวอย่าง downstream:
```ts
// In config/agentConfig.ts
downstreamAgents: [
  { name: "placeGuide", publicDescription: "Nearby places and POIs" },
  { name: "tourTaxi", publicDescription: "Tours and taxi/transfer info" },
],
```

---

## Tool Standards / มาตรฐานของ Tools

- Prefer core schemas/handlers: `core`, `ui`, `skill`
- Custom tools: define schemas in `config/functions.ts` and handlers in `functions/handlers`
- Handler return shape: `{ success: boolean, ...data }` and include helpful fields like `message`, `error`, `currentView`
- Language: auto-detect from latest user message and reply accordingly (Thai/English)

- ใช้ core เป็นหลัก: `core`, `ui`, `skill`
- หากต้องเพิ่ม custom tools: กำหนด schema ที่ `config/functions.ts` และ handler ที่ `functions/handlers`
- รูปแบบผลลัพธ์ของ handler: `{ success: boolean, ...data }` และควรมี `message`, `error`, `currentView` หากเป็นประโยชน์
- ภาษา: ตรวจจับอัตโนมัติจากข้อความล่าสุดของผู้ใช้ และตอบกลับภาษาเดียวกัน

---

## Example: Minimal Agent / ตัวอย่างเอเจนต์แบบพื้นฐาน

```ts
// config/agentConfig.ts
import { AgentConfig } from "@/app/types";
import { getCoreSchemasByConfig, getCoreHandlersByConfig, createTransferBackHandler } from "../../core/functions";

const coreSchemas = getCoreSchemasByConfig({ core: true, ui: true, skill: true });
const coreHandlers = getCoreHandlersByConfig({ core: true, ui: true, skill: true });

const sampleAgent: AgentConfig = {
  name: "sampleAgent",
  publicDescription: "Sample agent using core functions",
  instructions: `Answer directly, in user's language. Be concise and helpful.`,
  tools: coreSchemas,
  toolLogic: {
    ...coreHandlers,
    transferBack: createTransferBackHandler("sampleAgent"),
  },
  transferSettings: {
    autoGenerateFirstMessage: false,
    waitForVoicePlayback: false,
  },
};

export default sampleAgent;
```

```ts
// index.ts
import { injectTransferTools, injectTransferBackTools } from "../core/functions";
import { AgentConfig } from "@/app/types";
import sampleAgent from "./config/agentConfig";

const agent: AgentConfig = sampleAgent;
let agents = injectTransferTools([agent]);
agents = injectTransferBackTools(agents, "default");
export default agents;
```

---

## QA Checklist / เช็กลิสต์ตรวจสอบ

- Name, description, instructions present
- Uses core schemas/handlers via config
- `transferBack` configured
- `index.ts` exports `AgentConfig[]` using injection utils
- Registered in `src/app/agents/index.ts`

- มีชื่อ คำอธิบาย คำสั่งงาน ครบถ้วน
- ใช้ core schemas/handlers ถูกต้อง
- ตั้งค่า `transferBack` แล้ว
- `index.ts` export `AgentConfig[]` และใช้ injection ครบ
- ลงทะเบียนใน `src/app/agents/index.ts` แล้ว

---

## Notes on Intention System / หมายเหตุระบบ Intention

Agents can leverage the core intention functions (e.g., `intentionChange`) when `core: true` is enabled. For specialized flows (like Thai Resort Guide), keep agent-specific handlers in `functions/handlers` and keep prompts within `instructions`.

เอเจนต์สามารถใช้ฟังก์ชัน intention จาก core (เช่น `intentionChange`) เมื่อเปิดใช้ `core: true` หากมีฟลว์เฉพาะ (เช่น Thai Resort Guide) ให้เก็บ handler เฉพาะไว้ใน `functions/handlers` และข้อความระบบไว้ใน `instructions`


