/**
 * Skill Schemas Index
 * Skills to extend agent availability
 */

export { knowledgeSearchSchema } from './knowledge-search';
export { webSearchSchema } from './web-search';
export { httpRequestSchema } from './http-request';
export { ragSearchSchema } from './rag-search';
export { textSummarizeSchema } from './text-summarize';
export { timeNowSchema } from './time-now';

// Export all skill schemas as array
import { knowledgeSearchSchema } from './knowledge-search';
import { webSearchSchema } from './web-search';
import { httpRequestSchema } from './http-request';
import { ragSearchSchema } from './rag-search';
import { textSummarizeSchema } from './text-summarize';
import { timeNowSchema } from './time-now';

export const SKILL_SCHEMAS = [
  knowledgeSearchSchema,
  webSearchSchema,
  httpRequestSchema,
  ragSearchSchema,
  textSummarizeSchema,
  timeNowSchema,
]; 