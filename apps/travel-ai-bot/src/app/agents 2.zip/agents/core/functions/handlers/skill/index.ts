/**
 * Skill Handlers Index
 * Skills to extend agent availability
 */

export { knowledgeSearchHandler } from './knowledge-search';
export { webSearchHandler } from './web-search';
export { httpRequestHandler } from './http-request';
export { ragSearchHandler } from './rag-search';
export { textSummarizeHandler } from './text-summarize';
export { timeNowHandler } from './time-now';

// Export all skill handlers as object
import { knowledgeSearchHandler } from './knowledge-search';
import { webSearchHandler } from './web-search';
import { httpRequestHandler } from './http-request';
import { ragSearchHandler } from './rag-search';
import { textSummarizeHandler } from './text-summarize';
import { timeNowHandler } from './time-now';

export const SKILL_HANDLERS = {
  knowledgeSearch: knowledgeSearchHandler,
  webSearch: webSearchHandler,
  httpRequest: httpRequestHandler,
  ragSearch: ragSearchHandler,
  textSummarize: textSummarizeHandler,
  timeNow: timeNowHandler,
}; 