export const textSummarizeHandler = async (args: any) => {
  const { text, maxTokens = 120, style = 'paragraph' } = args || {};
  if (!text) return { success: false, error: 'text_required' };
  // naive summarization: take first N characters/lines as placeholder
  const limit = Math.max(60, Math.min(800, maxTokens * 4));
  const summary = text.length > limit ? text.slice(0, limit) + '…' : text;
  const payload = style === 'bullet'
    ? summary.split(/\n+/).slice(0, 6).map(s => s.trim()).filter(Boolean)
    : summary;
  return { success: true, summary: payload };
};
