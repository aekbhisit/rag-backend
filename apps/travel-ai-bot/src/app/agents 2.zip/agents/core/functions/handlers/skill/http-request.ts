const DEFAULT_TIMEOUT = 8000;
const ALLOWED_DOMAINS = [
  'example.com',
  'api.example.com'
];

function isAllowedUrl(urlStr: string): boolean {
  try {
    const u = new URL(urlStr);
    return ALLOWED_DOMAINS.includes(u.hostname);
  } catch { return false; }
}

export const httpRequestHandler = async (args: any) => {
  const { method, url, headers, body, timeoutMs } = args || {};
  if (!isAllowedUrl(url)) {
    return { success: false, error: 'URL not allowed' };
  }
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), Math.min(timeoutMs || DEFAULT_TIMEOUT, 15000));
  try {
    const res = await fetch(url, { method, headers, body, signal: controller.signal });
    const text = await res.text();
    return { success: true, status: res.status, headers: Object.fromEntries(res.headers.entries()), body: text };
  } catch (e: any) {
    return { success: false, error: e?.message || 'request_failed' };
  } finally { clearTimeout(id); }
};
