## Agent Structure Specification (For AI Agent Generation Only)

Purpose: Provide a deterministic, English-only specification that an AI must follow to create a new agent that integrates correctly with the existing core functions and runtime.

Do not include user-facing prose. Use the steps, constraints, and templates exactly. Prefer reuse of core schemas/handlers over custom logic.

---

### 1) Required Output (Files to create/modify)

For a new agent named <AgentName> (kebab or camel is fine, consistent across files):

- Create directory: `src/app/agents/<AgentName>/`
- Create file: `src/app/agents/<AgentName>/config/agentConfig.ts`
- Create file: `src/app/agents/<AgentName>/index.ts`
- Modify file: `src/app/agents/index.ts` (register the agent set)

Optional (only if needed):
- `src/app/agents/<AgentName>/config/functions.ts` (custom function schemas)
- `src/app/agents/<AgentName>/functions/handlers/*.ts` (custom handlers)
- `data/`, `services/`, `hooks/`, `types/` (agent-local assets)

---

### 2) Agent Contract (AgentConfig)

Every agent must export an `AgentConfig` from `config/agentConfig.ts` with:
- `name: string` — unique, stable key
- `publicDescription: string` — brief description
- `instructions: string` — system prompt for behavior
- `tools: Tool[]` — JSON schemas for functions (prefer core)
- `toolLogic: Record<string, (args:any)=>Promise<any>>` — handlers by function name
- `transferSettings: { autoGenerateFirstMessage?: boolean; waitForVoicePlayback?: boolean; initialPrompt?: string; initialSystemPrompt?: string }`

Optional:
- `downstreamAgents?: { name: string; publicDescription?: string }[]` — only if this agent dispatches/forwards to other agents.

Return contract for all handlers:
- Must resolve to an object containing `success: boolean`
- Include informative fields when relevant: `message`, `error`, `currentView`, domain payload, counts, ids, etc.

Language behavior:
- Detect user language from latest message; reply in the same language. Keep responses concise.

---

### 3) Core Reuse (Mandatory preference)

Use core schemas and handlers to avoid duplication:
- Import from `src/app/agents/core/functions`
- Use `getCoreSchemasByConfig` and `getCoreHandlersByConfig` with a `CoreFunctionConfig`:
  - `core: true` → essential intelligence (e.g., `intentionChange`, `transferAgents`, `transferBack`)
  - `ui: true` → UI/navigation helpers (e.g., `navigateToMain`, `navigateToPrevious`)
  - `skill: true` → skills (e.g., `knowledgeSearch`, `webSearch`)
- Add a per-agent `transferBack` via `createTransferBackHandler(<agentName>)`

---

### 4) Export Pattern (index.ts)

Each agent folder must export an array `AgentConfig[]` from `index.ts` and apply dynamic injections:
- `injectTransferTools([...])` adds per-agent `transferAgents` schemas based on `downstreamAgents`
- `injectTransferBackTools([...], "default")` adds `transferBack` schema for non-default agents

---

### 5) Registration (src/app/agents/index.ts)

- Import the agent folder default export
- Add it to `allAgentSets` with a key equal to the agent `name`
- Ensure no key collisions

---

### 6) Transfers

- To enable dispatching to other agents: define `downstreamAgents` in the agent config; dynamic injection will restrict `destination_agent` to these names.
- Always include and wire `transferBack` via `createTransferBackHandler(<agentName>)` and `injectTransferBackTools`.

---

### 7) Minimal Templates (copy, then fill)

config/agentConfig.ts
```ts
import { AgentConfig } from "@/app/types";
import {
  getCoreSchemasByConfig,
  getCoreHandlersByConfig,
  createTransferBackHandler,
  type CoreFunctionConfig,
} from "../../core/functions";

const CORE_CONFIG: CoreFunctionConfig = { core: true, ui: true, skill: true };
const coreSchemas = getCoreSchemasByConfig(CORE_CONFIG);
const coreHandlers = getCoreHandlersByConfig(CORE_CONFIG);

const <AgentName>: AgentConfig = {
  name: "<AgentName>",
  publicDescription: "<Short description>",
  instructions: `
    Respond in the user's language. Answer directly. Keep replies concise.
  `,
  tools: coreSchemas,
  toolLogic: {
    ...coreHandlers,
    transferBack: createTransferBackHandler("<AgentName>"),
    // Optional: add or override handlers below
  },
  transferSettings: {
    autoGenerateFirstMessage: false,
    waitForVoicePlayback: false,
  },
  // Optional: uncomment only if this agent dispatches to others
  // downstreamAgents: [
  //   { name: "placeGuide", publicDescription: "Nearby places and POIs" },
  //   { name: "tourTaxi", publicDescription: "Tours and taxi/transfer info" },
  // ],
};

export default <AgentName>;
```

index.ts
```ts
import { injectTransferTools, injectTransferBackTools } from "../core/functions";
import { AgentConfig } from "@/app/types";
import <AgentName> from "./config/agentConfig";

const agent: AgentConfig = <AgentName>;
let agents = injectTransferTools([agent]);
agents = injectTransferBackTools(agents, "default");

export default agents; // AgentConfig[]
```

src/app/agents/index.ts (registration)
```ts
import <AgentName> from "./<AgentName>";

export const allAgentSets = {
  // existing entries ...
  <AgentName>,
};
```

Custom schema (only if required): `config/functions.ts`
```ts
import type { Tool } from "@/app/types";

export const customTools: Tool[] = [
  {
    type: "function",
    name: "myCustomFunction",
    description: "<What it does>",
    parameters: {
      type: "object",
      properties: {
        paramA: { type: "string", description: "..." },
      },
      required: ["paramA"],
    },
  },
];
```

Custom handler example: `functions/handlers/custom.ts`
```ts
export async function myCustomFunction(args: any) {
  const { paramA } = args || {};
  if (!paramA) return { success: false, error: "paramA is required" };
  // Implement logic...
  return { success: true, result: { paramA } };
}
```

Wire custom tool/handler in `agentConfig.ts` (only if needed):
```ts
import { customTools } from "../config/functions";
import { myCustomFunction } from "../functions/handlers/custom";

tools: [...coreSchemas, ...customTools],
toolLogic: { ...coreHandlers, myCustomFunction, transferBack: createTransferBackHandler("<AgentName>") }
```

Example (placeGuide style):
```ts
// config/functions.ts
import type { Tool } from "@/app/types";

export const placeGuideTools: Tool[] = [
  {
    type: "function",
    name: "placeKnowledgeSearch",
    description: "Search nearby places/POIs with optional explicit filters.",
    parameters: {
      type: "object",
      properties: {
        searchQuery: { type: "string" },
        category: { type: "string", enum: ["Cafe", "Restaurant", "Attraction", ""] },
        lat: { type: "number" },
        long: { type: "number" },
        maxDistanceKm: { type: "number" },
        maxResults: { type: "number" },
      },
      required: ["searchQuery"],
    },
  },
];

// config/agentConfig.ts
import { placeGuideTools } from "../config/functions";
import { placeGuideKnowledgeSearchHandler } from "../functions/handlers";

tools: [...coreSchemas, ...placeGuideTools],
toolLogic: {
  ...coreHandlers,
  transferBack: createTransferBackHandler("placeGuide"),
  knowledgeSearch: placeGuideKnowledgeSearchHandler,      // core alias
  placeKnowledgeSearch: placeGuideKnowledgeSearchHandler, // custom schema
}
```

---

### 8) Constraints and Naming Rules

- Do not modify core files in `src/app/agents/core/`
- Do not duplicate core schemas/handlers; reuse via `getCoreSchemasByConfig`/`getCoreHandlersByConfig`
- All handlers must return `{ success: boolean, ... }`
- Keep function names stable; do not shadow core names unless intentionally overriding behavior
- `name` in `AgentConfig` must match the registration key in `allAgentSets`
- Use concise `instructions` and avoid greetings unless necessary for the agent role

---

### 9) Validation Checklist (must pass)

- `config/agentConfig.ts` exports a valid `AgentConfig`
- `index.ts` exports `AgentConfig[]` and applies injection utils
- Agent is registered in `src/app/agents/index.ts`
- `transferBack` present via handler factory and injection
- No TypeScript/lint errors
- If `downstreamAgents` provided, `transferAgents` schema is injected (enum-restricted)
- Handlers return `{ success: boolean, ... }` consistently

---

### 10) Example: Minimal Working Agent (copy and replace <AgentName>)

`config/agentConfig.ts`
```ts
import { AgentConfig } from "@/app/types";
import { getCoreSchemasByConfig, getCoreHandlersByConfig, createTransferBackHandler } from "../../core/functions";

const coreSchemas = getCoreSchemasByConfig({ core: true, ui: true, skill: true });
const coreHandlers = getCoreHandlersByConfig({ core: true, ui: true, skill: true });

const <AgentName>: AgentConfig = {
  name: "<AgentName>",
  publicDescription: "<Short description>",
  instructions: `Answer directly, in the user's language. Be concise.",
  tools: coreSchemas,
  toolLogic: {
    ...coreHandlers,
    transferBack: createTransferBackHandler("<AgentName>")
  },
  transferSettings: { autoGenerateFirstMessage: false, waitForVoicePlayback: false },
};

export default <AgentName>;
```

`index.ts`
```ts
import { injectTransferTools, injectTransferBackTools } from "../core/functions";
import { AgentConfig } from "@/app/types";
import <AgentName> from "./config/agentConfig";

const agent: AgentConfig = <AgentName>;
let agents = injectTransferTools([agent]);
agents = injectTransferBackTools(agents, "default");
export default agents;
```

End of specification.
