/**
 * Dataset of Thai resort categories and listings
 */

export interface ResortArticle {
  id: string;
  name: string;
}

export interface ResortCategoryData {
  id: string;
  displayName: string;
  articles: ResortArticle[];
}

export const CATEGORIES = {
  BEACH: 'beach',
  MOUNTAIN: 'mountain',
  ISLAND: 'island',
  SPA: 'spa',
  CULTURAL: 'cultural'
} as const;

export const CATEGORY_NAMES = {
  [CATEGORIES.BEACH]: 'Beach Resorts',
  [CATEGORIES.MOUNTAIN]: 'Mountain Retreats',
  [CATEGORIES.ISLAND]: 'Island Escapes',
  [CATEGORIES.SPA]: 'Wellness & Spa',
  [CATEGORIES.CULTURAL]: 'Cultural Experiences'
} as const;

// Full dataset of resort categories and their articles
export const resortCategoriesData: ResortCategoryData[] = [
  {
    id: CATEGORIES.BEACH,
    displayName: CATEGORY_NAMES[CATEGORIES.BEACH],
    articles: [
      { id: 'b1', name: 'Phuket Luxury Beach Resorts' },
      { id: 'b2', name: 'Koh Samui Beachfront Villas' },
      { id: 'b3', name: 'Krabi\'s Hidden Beach Retreats' }
    ]
  },
  {
    id: CATEGORIES.MOUNTAIN,
    displayName: CATEGORY_NAMES[CATEGORIES.MOUNTAIN],
    articles: [
      { id: 'm1', name: 'Chiang Mai Mountaintop Retreats' },
      { id: 'm2', name: 'Pai Riverside Mountain Lodges' },
      { id: 'm3', name: 'Doi Inthanon Luxury Camps' }
    ]
  },
  {
    id: CATEGORIES.ISLAND,
    displayName: CATEGORY_NAMES[CATEGORIES.ISLAND],
    articles: [
      { id: 'i1', name: 'Phi Phi Islands Private Resorts' },
      { id: 'i2', name: 'Koh Lipe Boutique Stays' },
      { id: 'i3', name: 'Similan Islands Eco Retreats' }
    ]
  },
  {
    id: CATEGORIES.SPA,
    displayName: CATEGORY_NAMES[CATEGORIES.SPA],
    articles: [
      { id: 's1', name: 'Bangkok Luxury Spa Resorts' },
      { id: 's2', name: 'Hua Hin Wellness Sanctuaries' },
      { id: 's3', name: 'Koh Phangan Detox Retreats' }
    ]
  },
  {
    id: CATEGORIES.CULTURAL,
    displayName: CATEGORY_NAMES[CATEGORIES.CULTURAL],
    articles: [
      { id: 'c1', name: 'Sukhothai Heritage Stays' },
      { id: 'c2', name: 'Ayutthaya Historical Resorts' },
      { id: 'c3', name: 'Lanna Cultural Experiences' }
    ]
  }
];

// Helper function to get articles for a specific category
export const getArticlesByCategory = (categoryId: string): ResortArticle[] => {
  const category = resortCategoriesData.find(cat => cat.id === categoryId);
  return category?.articles || [];
};

// Helper function to get a category name from its ID
export const getCategoryName = (categoryId: string): string => {
  return CATEGORY_NAMES[categoryId as keyof typeof CATEGORY_NAMES] || categoryId;
}; 