# Thai Resort Guide Agent

## Overview
AI-powered resort guide with automatic intention detection and adaptive response styles.

## Architecture

### Core Files
```
src/app/agents/thaiResortGuide/
├── index.ts                    # Main exports and agent configuration
├── README.md                   # This documentation
├── config/
│   ├── agentConfig.ts         # Base agent configuration
│   └── functions.ts           # OpenAI function definitions
├── data/
│   └── resortData.ts          # Resort categories and article data
├── hooks/
│   └── useFunctionHandler.ts  # Main function call handler
├── services/
│   ├── actionHandlers.ts      # Function execution handlers
│   └── aiIntentionHandler.ts  # AI intention detection & prompts
└── types/
    └── intentions.ts          # Type definitions
```

## AI Intention System

### How It Works
1. **AI Detection**: AI monitors conversation and detects intention changes
2. **Function Call**: AI calls `intentionChange(intent, style, reasoning)` when needed
3. **Prompt Update**: System returns new behavior instructions to AI
4. **Adaptive Response**: AI adapts tone and approach automatically

### Intention Types
- **explore**: Browse/discover resort options
- **learn**: Get detailed information about resorts
- **decide**: Compare options and get recommendations  
- **act**: Book or take action on a resort

### Style Types
- **guided**: Step-by-step help for new/unsure users
- **quick**: Fast, efficient responses for time-conscious users
- **detailed**: Comprehensive, thorough information

### Example Flow
```
User: "I want to explore beach resorts step by step"
↓
AI: [Detects explore/guided intention]
↓ 
AI: Calls intentionChange(intent="explore", style="guided")
↓
System: Returns warm, guiding behavior instructions
↓
AI: Responds warmly + calls viewResortCategory("beach")
```

## Functions

### AI-Controlled
- `intentionChange(intent, style, reasoning)` - Auto-called by AI

### Navigation
- `viewResortCategory(categoryId)` - Show resorts in category
- `viewResortDetail(articleId)` - Show specific resort details
- `navigateToMainPage()` - Go to main categories
- `navigateBack()` - Go back one level

### Utility  
- `knowledge(query)` - Search resort knowledge base
- `transferBack()` - Return to default agent

## Benefits

✅ **Multi-Language**: Works in any language automatically  
✅ **Context-Aware**: Understands conversation flow and user needs  
✅ **Adaptive**: Changes tone and approach based on user intent  
✅ **Seamless**: Invisible to users, natural conversation  
✅ **Maintainable**: No complex pattern maintenance required  

## Recent Cleanup (2025-01-25)

### Removed Files
- `hooks/useIntentionDetector.ts` - Old pattern-based detection
- `hooks/useIntentionHandler.ts` - Old manual intention handling  
- `services/aiIntentionService.ts` - Unused API-based service

### Kept Files
All remaining files are actively used and essential for the AI intention system.

### Migration
- Old pattern matching → AI-powered detection
- Manual intention updates → Automatic function calls
- Single language support → Multi-language support 