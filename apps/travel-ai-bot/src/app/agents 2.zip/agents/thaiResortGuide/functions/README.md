# Thai Resort Guide Functions

This directory contains all function definitions and implementations for the Thai Resort Guide agent, following the same clean architecture pattern as the core functions.

## 📁 Structure

```
functions/
├── schemas/                    # Function schemas (OpenAI function definitions)
│   ├── resort/                 # Resort-specific function schemas
│   │   ├── category.ts         # viewResortCategory schema
│   │   ├── detail.ts           # viewResortDetail schema
│   │   ├── search.ts           # searchResorts schema
│   │   ├── compare.ts          # compareResorts schema
│   │   └── index.ts            # Resort schema exports
│   └── index.ts                # All schema exports
├── handlers/                   # Function implementations
│   ├── resort/                 # Resort-specific function handlers
│   │   ├── category.ts         # viewResortCategory handler
│   │   ├── detail.ts           # viewResortDetail handler
│   │   ├── search.ts           # searchResorts handler
│   │   ├── compare.ts          # compareResorts handler
│   │   └── index.ts            # Resort handler exports
│   └── index.ts                # All handler exports
├── index.ts                    # Main function exports
└── README.md                   # This file
```

## 🎯 Available Functions

### Resort Functions
- **`viewResortCategory`** - View a specific category of Thai resorts
- **`viewResortDetail`** - View detailed information about a specific resort
- **`searchResorts`** - Search for resorts based on criteria
- **`compareResorts`** - Compare multiple resorts

### Core Functions (Inherited)
- **`intentionChange`** - Handle AI-detected intention changes
- **`transferAgents`** - Transfer to another agent
- **`transferBack`** - Transfer back to previous agent
- **`knowledgeSearch`** - Search the knowledge base
- **`webSearch`** - Search the web
- **`navigateToMain`** - Navigate to main page
- **`navigateToPrevious`** - Navigate to previous page

## 🔧 Usage

### In Agent Configuration (`config/functions.ts`)
```typescript
import { getThaiResortSchemas } from '../functions';

// Get all schemas (core + thai resort specific)
export const thaiResortFunctions = getThaiResortSchemas();
```

### In Function Handler (`hooks/useFunctionHandler.ts`)
```typescript
import { getThaiResortHandlers } from '../functions';

// Get all handlers (core + thai resort specific)
const allHandlers = getThaiResortHandlers();
```

## 🏗️ Architecture Benefits

### **Clean Separation**
- **Schemas**: Pure function definitions for OpenAI
- **Handlers**: Business logic implementations
- **Clear boundaries** between definition and implementation

### **Easy Reusability**
- Core functions automatically included
- Agent-specific functions cleanly separated
- Simple import pattern for other agents

### **Maintainability**
- Single responsibility principle
- Easy to add new functions
- Clear file organization

### **Type Safety**
- Proper TypeScript interfaces
- Type-safe function arguments
- Compile-time error checking

## 📝 Adding New Functions

### 1. Create Schema
```typescript
// schemas/resort/newFunction.ts
export const newFunctionSchema: Tool = {
  type: 'function',
  name: 'newFunction',
  description: 'Description of the new function',
  parameters: {
    type: 'object',
    properties: {
      // Define parameters
    },
    required: ['requiredParam']
  }
};
```

### 2. Create Handler
```typescript
// handlers/resort/newFunction.ts
export interface NewFunctionArgs {
  requiredParam: string;
}

export const newFunctionHandler = async (args: NewFunctionArgs) => {
  // Implementation logic
  return { success: true };
};
```

### 3. Export in Index Files
```typescript
// schemas/resort/index.ts
export { newFunctionSchema } from './newFunction';

// handlers/resort/index.ts
export { newFunctionHandler } from './newFunction';
```

## 🔄 Integration Pattern

This structure follows the same pattern as `/core/functions/` for consistency:

1. **Schemas** define what functions are available to OpenAI
2. **Handlers** implement the actual function logic
3. **Index files** provide clean exports
4. **Main index** combines core and agent-specific functions

## 🚀 Core Function Integration

The Thai Resort Guide automatically inherits all core functions:

```typescript
const CORE_FUNCTION_CONFIG: CoreFunctionConfig = {
  core: true,      // intentionChange, transferAgents, transferBack
  skill: true,     // knowledgeSearch, webSearch
  ui: true,        // navigateToMain, navigateToPrevious
};
```

This ensures consistent behavior across all agents while allowing for agent-specific customization. 